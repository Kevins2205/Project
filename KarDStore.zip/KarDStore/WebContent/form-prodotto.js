 // Oggetto per le opzioni dei tipi in base alla categoria
        const types = {
            pokemon: ["carta singola", "mazzo", "bustina", "tin", "box"],
            "dragon ball": ["lamin card", "mazzo", "bustina", "box"],
            magic: ["carta singola", "mazzo", "bustina", "box"],
            "yu-gi-oh!": ["carta singola", "mazzo", "bustina", "tin", "box"]
        };

        // Funzione per aggiornare il menu dei tipi in base alla categoria selezionata
        
        function updateTypeOptions() {
    const category = document.getElementById("select-categoria").value;
    const typeSelect = document.getElementById("select-tipo");
    typeSelect.innerHTML = ""; // Pulisci le opzioni esistenti

    if (category) {
        const defaultOption = document.createElement("option");
        defaultOption.value = "";
        defaultOption.text = "Seleziona un tipo";
        typeSelect.add(defaultOption);

        types[category].forEach(type => {
            const option = document.createElement("option");
            option.value = type;
            option.text = type;
            typeSelect.add(option);
        });
    }
}
        
        
        // Funzione per validare il form
function validateForm() {
    const form = document.forms["add-pdr"]; 
    const nome = form["nome"].value.trim();
    const descrizione = form["descrizione"].value.trim();
    const prezzo = form["prezzo"].value.trim();
    const iva = form["iva"].value.trim();
    const categoria = form["select-categoria"].value.trim();
    const tipo = form["select-tipo"].value.trim();
    const quantità = form["quantita"].value.trim();
    const fileInput = form["talkPhoto"];

    const nomePattern = /^(?=.{1,100}$)[a-zA-Z0-9\s\-']{1,100}$/;
    const descrizionePattern = /^(?=.{1,500}$)[a-zA-Z0-9\s\-',.]{1,500}$/;
    const prezzoPattern = /^\d{0,9}(\.\d{1,2})?$/;
    const ivaPattern = /^\d{1,2}(\.\d{1,2})?$/;
    const quantitàPattern = /^\d+$/;
	
	 const errorMessage = document.getElementById('register-error');
    const nomeMessage = document.getElementById('nome-error');
    const descrizioneMessage = document.getElementById('descrizione-error');
    const prezzoMessage = document.getElementById('prezzo-error');
    const ivaMessage = document.getElementById('iva-error');
    const categoriaMessage = document.getElementById('categoria-error');
    const tipoMessage = document.getElementById('tipo-error');
    const quantitàMessage = document.getElementById('quantità-error');
    const fotoMessage = document.getElementById('foto-error');
	
	
	 errorMessage.innerHTML = ''; 
    nomeMessage.innerHTML = '';
    descrizioneMessage.innerHTML = '';
    prezzoMessage.innerHTML = '';
    ivaMessage.innerHTML = '';
    categoriaMessage.innerHTML = '';
    tipoMessage.innerHTML = '';
    quantitàMessage.innerHTML = '';
    fotoMessage.innerHTML = '';

    let isValid = true;

    if (nome === '') {
        nomeMessage.innerHTML = '<h5>Il campo Nome è obbligatorio.</h5>';
        isValid = false;
    } else if (!nomePattern.test(nome)) {
        nomeMessage.innerHTML = '<h5>Il campo Nome deve essere massimo di 100 caratteri.</h5>';
        isValid = false;
    }

    if (descrizione === '') {
        descrizioneMessage.innerHTML = '<h5>Il campo Descrizione è obbligatorio.</h5>';
        isValid = false;
    } else if (!descrizionePattern.test(descrizione)) {
        descrizioneMessage.innerHTML = '<h5>Il campo Descrizione deve essere massimo di 500 caratteri.</h5>';
        isValid = false;
    }

    if (prezzo === '') {
        prezzoMessage.innerHTML = '<h5>Il campo Prezzo è obbligatorio.</h5>';
        isValid = false;
    } else if (!prezzoPattern.test(prezzo)) {
        prezzoMessage.innerHTML = '<h5>Il campo Prezzo deve essere un numero valido con massimo 2 decimali.</h5>';
        isValid = false;
    }

    if (iva === '') {
        ivaMessage.innerHTML = '<h5>Il campo IVA è obbligatorio.</h5>';
        isValid = false;
    } else if (!ivaPattern.test(iva)) {
        ivaMessage.innerHTML = '<h5>Il campo IVA deve essere un numero intero valido.</h5>';
        isValid = false;
    }

    if (categoria === '') {
        categoriaMessage.innerHTML = '<h5>Il campo Categoria è obbligatorio.</h5>';
        isValid = false;
    }

    if (tipo === '') {
        tipoMessage.innerHTML = '<h5>Il campo Tipo è obbligatorio.</h5>';
        isValid = false;
    }

    if (quantità === '') {
        quantitàMessage.innerHTML = '<h5>Il campo Quantità è obbligatorio.</h5>';
        isValid = false;
    } else if (!quantitàPattern.test(quantità)) {
        quantitàMessage.innerHTML = '<h5>Il campo Quantità deve essere un numero intero valido.</h5>';
        isValid = false;
    }

    if (!fileInput.files.length) {
        fotoMessage.innerHTML = '<h5>Il campo Foto è obbligatorio.</h5>';
        isValid = false;
    }
	
	
	 if(!isValid){
		errorMessage.innerHTML = '<h4>Si prega di correggere gli errori sopra indicati.</h4>';
		return false;
	}
	
	 errorMessage.innerHTML = ''; 
	 nomeMessage.innerHTML = '';
    descrizioneMessage.innerHTML = '';
    prezzoMessage.innerHTML = '';
    ivaMessage.innerHTML = '';
    categoriaMessage.innerHTML = '';
    tipoMessage.innerHTML = '';
    quantitàMessage.innerHTML = '';
    fotoMessage.innerHTML = '';
    return isValid;
}