function validateForm() {
    const form = document.forms[0];
    const nome = form["nome"].value.trim();
    const descrizione = form["descrizione"].value.trim();
    const prezzo = form["prezzo"].value.trim();
    const iva = form["iva"].value.trim();
    const quantita = form["quantita"].value.trim();

     const nomePattern = /^(?=.{1,100}$)[\s\S]*$/;
    const prezzoPattern = /^\d{1,7}(\.\d{1,2})?$/;
    const ivaPattern = /^\d{1,2}(\.\d{1,2})?$/;
    const quantitaPattern = /^\d+$/;

    const errorMessage = document.getElementById('consegna-error');
    const nomeMessage = document.getElementById('nome-error');
    const descrizioneMessage = document.getElementById('descrizione-error');
    const prezzoMessage = document.getElementById('prezzo-error');
    const ivaMessage = document.getElementById('iva-error');
    const quantitaMessage = document.getElementById('quantita-error');

    // Resetta tutti i messaggi di errore
    errorMessage.innerHTML = '';
    nomeMessage.innerHTML = '';
    descrizioneMessage.innerHTML = '';
    prezzoMessage.innerHTML = '';
    ivaMessage.innerHTML = '';
    quantitaMessage.innerHTML = '';

    let isValid = true;

    // Validazione dei campi
    if (!nome) {
        nomeMessage.innerHTML = '<h5>Il campo Nome è obbligatorio.</h5>';
        isValid = false;
    } else if (!nomePattern.test(nome)) {
        nomeMessage.innerHTML = '<h5>Il campo Nome deve essere di massimo 300 caratteri alfanumerici.</h5>';
        isValid = false;
    }

    if (!descrizione) {
        descrizioneMessage.innerHTML = '<h5>Il campo Descrizione è obbligatorio.</h5>';
        isValid = false;
    }

    if (!prezzo) {
        prezzoMessage.innerHTML = '<h5>Il campo Prezzo è obbligatorio.</h5>';
        isValid = false;
    } else if (!prezzoPattern.test(prezzo)) {
        prezzoMessage.innerHTML = '<h5>Il campo Prezzo deve essere un numero valido con massimo 7 cifre intere e due decimali.</h5>';
        isValid = false;
    }

    if (!iva) {
        ivaMessage.innerHTML = '<h5>Il campo IVA è obbligatorio.</h5>';
        isValid = false;
    } else if (!ivaPattern.test(iva)) {
        ivaMessage.innerHTML = '<h5>Il campo IVA deve essere un numero valido con massimo 2 cifre intere e due decimali.</h5>';
        isValid = false;
    }

    if (!quantita) {
        quantitaMessage.innerHTML = '<h5>Il campo Quantità disponibile è obbligatorio.</h5>';
        isValid = false;
    } else if (!quantitaPattern.test(quantita)) {
        quantitaMessage.innerHTML = '<h5>Il campo Quantità disponibile deve essere un numero intero.</h5>';
        isValid = false;
    }

    // Se non è valido, blocca l'invio del form
    if (!isValid) {
        errorMessage.innerHTML = '<h4>Si prega di correggere gli errori sopra indicati.</h4>';
        return false;
    }

    return true;
}

// Aggiungi un listener per l'evento submit del form
document.addEventListener('DOMContentLoaded', function() {
    const form = document.forms[0];
    form.addEventListener('submit', function(event) {
        if (!validateForm()) {
            event.preventDefault();
        }
    });
});
