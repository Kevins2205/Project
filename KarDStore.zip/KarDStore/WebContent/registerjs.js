function validateForm() {
    const form = document.forms["form-register"];
    const nome = form["nome"].value.trim();
    const cognome = form["cognome"].value.trim();
    const email = form["email"].value.trim();
    const tel = form["tel"].value.trim();
    const username = form["username"].value.trim();
    const pw = form["pw"].value.trim();
    const data_nascita = form["data_nascita"].value.trim();
    const citta = form["citta"].value.trim();
    const via = form["via"].value.trim();
    const cap = form["cap"].value.trim();
    const usernamePattern = /^[a-zA-Z][a-zA-Z0-9]{0,49}$/;
    const emailPattern=/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
	const nomePattern=/^(?=.{1,30}$)[a-zA-Z]*( [a-zA-Z]*){0,2}$/;  //un nome completo italiano puo avere al max 3 nomi
	const cognomePattern=/^(?=.{1,30}$)[a-zA-Z]*( [a-zA-Z]*){0,1}$/;  //max due cognomi
	const pwPattern=/^(?=.*[A-Z])(?=.*[\W_])(?=.*\d).{8,}$/;
	const telPattern= /^\d{10}$/;
	const data_nascitaPattern= /^\d{4}-\d{2}-\d{2}$/;
	const cittaPattern=/^[a-zA-Z\u00C0-\u017F\s\-']{1,50}$/;
	const viaPattern=/^[a-zA-Z0-9\u00C0-\u017F\s,.\-']{1,100}$/;
	const capPattern=/^\d{5}$/;
 	
	
    const errorMessage = document.getElementById('register-error');
    const usernameMessage = document.getElementById('username-error');///*fare cosi anche per password*
    const emailMessage = document.getElementById('email-error');
	const nomeMessage = document.getElementById('nome-error');
	const cognomeMessage = document.getElementById('cognome-error');
	const pwMessage = document.getElementById('pw-error');
	const telMessage = document.getElementById('tel-error');
	const data_nascitaMessage = document.getElementById('date-error');
	const cittaMessage = document.getElementById('citta-error');
	const viaMessage = document.getElementById('via-error');
	const capMessage = document.getElementById('cap-error');
	
	
	
	
    errorMessage.innerHTML = ''; // Resetta il messaggio di errore generale
    usernameMessage.innerHTML = ''; // Resetta il messaggio di errore specifico per l'username
    emailMessage.innerHTML = '';
    nomeMessage.innerHTML = '';
    cognomeMessage.innerHTML = '';
    pwMessage.innerHTML = '';
    telMessage.innerHTML = '';
    data_nascitaMessage.innerHTML = '';
    cittaMessage.innerHTML = '';
    viaMessage.innerHTML = '';
    capMessage.innerHTML = '';
    
    
    
    
///*fare cosi anche per password*
   
    let isValid=true;
    // Validazione dei campi obbligatori
    if (nome === '') {
        nomeMessage.innerHTML = '<h5>Il campo Nome è obbligatorio.</h5>';
        isValid=false;
       
    }else if(!nomePattern.test(nome)){
		nomeMessage.innerHTML='<h5>Il campo Nome deve essere di massimo 30 lettere e al massimo di 3 nomi.</h5>';
		isValid=false;
	}

    if (cognome === '') {
        cognomeMessage.innerHTML = '<h5>Il campo Cognome è obbligatorio.</h5>';
        isValid=false;
        
    }else if(!cognomePattern.test(cognome)){
		cognomeMessage.innerHTML='<h5>Il campo Cognome deve essere di massimo 30 lettere e al massimo di 2 cognomi.</h5>';
		isValid=false;
	}

    if (email === '') {
        emailMessage.innerHTML = '<h5>Il campo Email è obbligatorio.</h5>';
        
        isValid = false;
    }	else if (!emailPattern.test(email)) {
        emailMessage.innerHTML = '<h5>Il campo Email è stato scritto in modo errato, assicurati di inserire una @ e che i domini siano giusti.(gmail.com/hotmail.it/...)</h5>';
        isValid = false;
    }

    if (tel === '') {
        telMessage.innerHTML = '<h5>Il campo Numero di telefono è obbligatorio.</h5>';
        isValid=false;
        
    }else if(!telPattern.test(tel)){
		telMessage.innerHTML='<h5>Il campo Telefono deve essere di 10 cifre.</h5>';
		isValid=false;
	}

    if (data_nascita === '') {
        data_nascitaMessage.innerHTML = '<h5>Il campo Data Di Nascita è obbligatorio.</h5>';
        isValid=false;
        
    }else if(!data_nascitaPattern.test(data_nascita)){
		data_nascitaMessage.innerHTML='<h5>Il campo Data Di Nascita deve essere in formato gg/mm/aaaa.</h5>';
		isValid=false;
	}else if (!isAtLeast14YearsOld(data_nascita)) {
        data_nascitaMessage.innerHTML = '<h5>Devi avere almeno 14 anni.</h5>';
        isValid = false;
    }

    if (citta === '') {
        cittaMessage.innerHTML = '<h5>Il campo Citta è obbligatorio.</h5>';
        isValid=false;
       
    }else if(!cittaPattern.test(citta)){
		cittaMessage.innerHTML='<h5>Il campo Citta deve essere al massimo di 50 caratteri compresi di caratteri speciali come \u0027,- gli spazi e gli accenti.</h5>';
		isValid=false;
	}

    if (via === '') {
        viaMessage.innerHTML = '<h5>Il campo Via è obbligatorio.</h5>';
        isValid=false;
       
    }else if(!viaPattern.test(via)){
		viaMessage.innerHTML='<h5>Il campo Indirizzo deve essere al massimo di 100 caratteri alfanumerici compresi di accenti.</h5>';
		isValid=false;
	}

    if (cap === '') {
        capMessage.innerHTML = '<h5>Il campo Cap è obbligatorio.</h5>';
        isValid=false;
        
    }else if(!capPattern.test(cap)){
		capMessage.innerHTML='<h5>Il campo Cap deve avere 5 cifre.</h5>';
		isValid=false;
	}

    // Validazione dell'username
    if (username === '') {
		usernameMessage.innerHTML = '<h5>Il campo Username è obbligatorio.</h5>';
        isValid = false;
       
    } else if (!usernamePattern.test(username)) {
        usernameMessage.innerHTML = '<h5>Il campo Username deve contenere solo numeri e lettere, deve iniziare con una lettera e deve essere di massimo 50 caratteri.</h5>';
        isValid = false;
    }///*fare cosi anche per password*
    
     if (pw === '') {
        pwMessage.innerHTML = '<h5>Il campo Password è obbligatorio.</h5>';
        isValid=false;
        
    } else if(!pwPattern.test(pw)){
		pwMessage.innerHTML='<h5>Il campo Password deve avere almeno 8 caratteri, una maiuscola e un carattere speciale.</h5>';
		isValid=false;
	}

    // Se è stato trovato solo un campo vuoto, mostriamo il messaggio specifico e blocchiamo l'invio del form
    
    if(!isValid){
		errorMessage.innerHTML = '<h4>Si prega di correggere gli errori sopra indicati.</h4>';
		return false;
	}

    
    
    
    
    // Se tutti i campi sono validi, resettiamo i messaggi di errore e consentiamo l'invio del form
    emailMessage.innerHTML = '';
    errorMessage.innerHTML = '';
    usernameMessage.innerHTML = '';///*fare cosi anche per password*
    nomeMessage.innerHTML = '';
    cognomeMessage.innerHTML = '';
    pwMessage.innerHTML = '';
    telMessage.innerHTML = '';
    data_nascitaMessage.innerHTML = '';
    cittaMessage.innerHTML = '';
    viaMessage.innerHTML = '';
    capMessage.innerHTML = '';
    return true;
    
    
   
    
    
}



function isAtLeast14YearsOld(dateString) {
    const [year, month, day] = dateString.split('-').map(Number);
    const birthDate = new Date(year, month - 1, day);
    const today = new Date();
    
    const age = today.getFullYear() - birthDate.getFullYear();
    const monthDiff = today.getMonth() - birthDate.getMonth();
    const dayDiff = today.getDate() - birthDate.getDate();

    if (age > 14 || (age === 14 && (monthDiff > 0 || (monthDiff === 0 && dayDiff >= 0)))) {
        return true;
    } else {
        return false;
    }
}




document.addEventListener('DOMContentLoaded', function() {
    const emailInput = document.querySelector('input[name="email"]');
    const emailError = document.getElementById('email-error');

    emailInput.addEventListener('blur', function() {
        const email = emailInput.value.trim();
        if (email) {
            fetch('RegisterServlet?action=checkEmail', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                },
                body: 'email=' + encodeURIComponent(email)
            })
            .then(response => response.json())
            .then(data => {
                if (data.emailExists) {
                    emailError.innerHTML = '<h5>Email gia in uso. Riprova.</h5>';
                } else {
                    emailError.innerHTML = '';
                }
            })
            .catch(error => {
                console.error('Errore durante il controllo dell\'email:', error);
            });
        }
    });
});


document.addEventListener('DOMContentLoaded', function() {
    const usernameInput = document.querySelector('input[name="username"]');
    const usernameError = document.getElementById('username-error');

    usernameInput.addEventListener('blur', function() {
        const username = usernameInput.value.trim();
        if (username) {
            fetch('RegisterServlet?action=checkUsername', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                },
                body: 'username=' + encodeURIComponent(username)
            })
            .then(response => response.json())
            .then(data => {
                if (data.usernameExists) {
                    usernameError.innerHTML = '<h5>Username gia in uso. Riprova.</h5>';
                } else {
                    usernameError.innerHTML = '';
                }
            })
            .catch(error => {
                console.error('Errore durante il controllo dell\'username:', error);
            });
        }
    });
});



