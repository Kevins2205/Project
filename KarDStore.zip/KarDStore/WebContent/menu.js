function toggleMenu() {
    const group = document.querySelector('.group');
    group.classList.toggle('active');
}
