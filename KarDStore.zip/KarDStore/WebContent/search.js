document.addEventListener('DOMContentLoaded', function() {
    console.log('DOM Content Loaded');  // Debug

    const searchInput = document.getElementById('searchInput');
    if (searchInput) {
        searchInput.addEventListener('input', function() {
            console.log('Input event triggered');  // Debug
            const query = this.value;
            if (query.length > 2) {
                fetchSuggestions(query);
            } else {
                const suggestionsDiv = document.getElementById('suggestions');
                if (suggestionsDiv) {
                    suggestionsDiv.innerHTML = '';
                } else {
                    console.error('Element with ID suggestions not found');  // Debug
                }
            }
        });
    } else {
        console.error('Element with ID searchInput not found');  // Debug
    }

    function fetchSuggestions(query) {
        console.log('Fetching suggestions for:', query);  // Debug
        const xhr = new XMLHttpRequest();
        xhr.open('GET', 'SearchServlet?query=' + encodeURIComponent(query), true);
        xhr.onreadystatechange = function() {
            if (xhr.readyState == 4 && xhr.status == 200) {
                console.log('Response received:', xhr.responseText);  // Debug
                try {
                    const results = JSON.parse(xhr.responseText);
                    displaySuggestions(results);
                } catch (e) {
                    console.error('Error parsing JSON:', e);
                    console.error('Response Text:', xhr.responseText); // Debug
                }
            }
        };
        xhr.send();
    }

    function displaySuggestions(results) {
        console.log('Displaying suggestions:', results);  // Debug
        const suggestionsDiv = document.getElementById('suggestions');
        if (suggestionsDiv) {
            suggestionsDiv.innerHTML = '';
            results.forEach(result => {
                const div = document.createElement('div');
                div.textContent = result.nome;
                div.classList.add('suggestion-item');
                div.addEventListener('click', function() {
                    window.location.href = 'DettaglioProdottoServlet?id=' + result.id;
                });
                suggestionsDiv.appendChild(div);
            });
        } else {
            console.error('Element with ID suggestions not found');  // Debug
        }
    }
});
