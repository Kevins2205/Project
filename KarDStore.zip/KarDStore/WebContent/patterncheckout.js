function validateForm() {
    const form = document.forms["form-consegna"];
    const nome = form["nome"].value.trim();
    const cognome = form["cognome"].value.trim();
    const citta = form["citta"].value.trim();
    const via = form["via"].value.trim();
    const cap = form["cap"].value.trim();

    const savedCard = form["savedCard"].value.trim();
    const scadenzacarta = form["scadenzacarta"].value.trim();
    const credenziali = form["credenziali"].value.trim();
    const numerocarta = form["numerocarta"].value.trim();
    const cvv = form["cvv"].value.trim();

    const nomePattern = /^(?=.{1,30}$)[a-zA-Z]*( [a-zA-Z]*){0,2}$/;
    const cognomePattern = /^(?=.{1,30}$)[a-zA-Z]*( [a-zA-Z]*){0,1}$/;
    const scadenzacartaPattern = /^(0[1-9]|1[0-2])-\d{2}$/;
    const cittaPattern = /^[a-zA-Z\u00C0-\u017F\s\-']{1,50}$/;
    const viaPattern = /^[a-zA-Z0-9\u00C0-\u017F\s,.\-']{1,100}$/;
    const capPattern = /^\d{5}$/;
    const numerocartaPattern = /^\d{16}$/;
    const cvvPattern = /^\d{3,4}$/;

    const errorMessage = document.getElementById('consegna-error');
    const metodiMessage = document.getElementById('metodi-error');
    const nomeMessage = document.getElementById('nome-error');
    const cognomeMessage = document.getElementById('cognome-error');
    const scadenzacartaMessage = document.getElementById('scadenza-error');
    const cittaMessage = document.getElementById('citta-error');
    const viaMessage = document.getElementById('via-error');
    const capMessage = document.getElementById('cap-error');
    const credenzialiMessage = document.getElementById('credenziali-error');
    const numerocartaMessage = document.getElementById('numerocarta-error');
    const cvvMessage = document.getElementById('cvv-error');

    // Resetta tutti i messaggi di errore
    errorMessage.innerHTML = '';
    nomeMessage.innerHTML = '';
    cognomeMessage.innerHTML = '';
    scadenzacartaMessage.innerHTML = '';
    cittaMessage.innerHTML = '';
    viaMessage.innerHTML = '';
    capMessage.innerHTML = '';
    credenzialiMessage.innerHTML = '';
    numerocartaMessage.innerHTML = '';
    cvvMessage.innerHTML = '';
    metodiMessage.innerHTML = '';

    let isValid = true;

    if (savedCard === "" && (credenziali === "" || numerocarta === "" || scadenzacarta === "" || cvv === "")) {
        metodiMessage.innerHTML = '<h5>Inserisci una nuova carta di credito o seleziona una carta salvata.</h5>';
        isValid = false;
    }

    // Validazione dei campi
    if (!nome) {
        nomeMessage.innerHTML = '<h5>Il campo Nome è obbligatorio.<h5>';
        isValid = false;
    } else if (!nomePattern.test(nome)) {
        nomeMessage.innerHTML = '<h5>Il campo Nome deve essere di massimo 30 lettere e al massimo di 3 nomi.<h5>';
        isValid = false;
    }

    if (!cognome) {
        cognomeMessage.innerHTML = '<h5>Il campo Cognome è obbligatorio.<h5>';
        isValid = false;
    } else if (!cognomePattern.test(cognome)) {
        cognomeMessage.innerHTML = '<h5>Il campo Cognome deve essere di massimo 30 lettere e al massimo di 2 cognomi.<h5>';
        isValid = false;
    }

    if (!citta) {
        cittaMessage.innerHTML = '<h5>Il campo Città è obbligatorio.<h5>';
        isValid = false;
    } else if (!cittaPattern.test(citta)) {
        cittaMessage.innerHTML = '<h5>Il campo Città deve essere al massimo di 50 caratteri compresi caratteri speciali.<h5>';
        isValid = false;
    }

    if (!via) {
        viaMessage.innerHTML = '<h5>Il campo Via è obbligatorio.<h5>';
        isValid = false;
    } else if (!viaPattern.test(via)) {
        viaMessage.innerHTML = '<h5>Il campo Via deve essere al massimo di 100 caratteri alfanumerici.<h5>';
        isValid = false;
    }

    if (!cap) {
        capMessage.innerHTML = '<h5>Il campo CAP è obbligatorio.<h5>';
        isValid = false;
    } else if (!capPattern.test(cap)) {
        capMessage.innerHTML = '<h5>Il campo CAP deve avere 5 cifre.<h5>';
        isValid = false;
    }

    if (savedCard === "") {
        if (!credenziali) {
            credenzialiMessage.innerHTML = '<h5>Il campo Credenziali è obbligatorio.<h5>';
            isValid = false;
        }

        if (!numerocarta) {
            numerocartaMessage.innerHTML = '<h5>Il campo Numero carta è obbligatorio.<h5>';
            isValid = false;
        } else if (!numerocartaPattern.test(numerocarta)) {
            numerocartaMessage.innerHTML = '<h5>Il campo Numero carta deve essere di 16 cifre.<h5>';
            isValid = false;
        }

        if (!scadenzacarta) {
            scadenzacartaMessage.innerHTML = '<h5>Il campo Data di scadenza è obbligatorio.<h5>';
            isValid = false;
        } else if (!scadenzacartaPattern.test(scadenzacarta)) {
            scadenzacartaMessage.innerHTML = '<h5>Il campo Data di scadenza deve essere in formato mm-aa.<h5>';
            isValid = false;
        } else if (!validateDate(scadenzacarta)) {
            scadenzacartaMessage.innerHTML = '<h5>Carta scaduta.<h5>';
            isValid = false;
        }

        if (!cvv) {
            cvvMessage.innerHTML = '<h5>Il campo CVV è obbligatorio.<h5>';
            isValid = false;
        } else if (!cvvPattern.test(cvv)) {
            cvvMessage.innerHTML = '<h5>Il campo CVV deve essere di 3 o 4 cifre.<h5>';
            isValid = false;
        }
    }

    // Se non è valido, blocca l'invio del form
    if (!isValid) {
        errorMessage.innerHTML = '<h4>Si prega di correggere gli errori sopra indicati.<h4>';
        return false;
    }

    return true;
}

function validateDate(dateStr) {
    const [monthStr, yearStr] = dateStr.split('-');
    const month = parseInt(monthStr, 10);
    const year = parseInt('20' + yearStr, 10);

    const currentDate = new Date();
    const currentMonth = currentDate.getMonth() + 1;
    const currentYear = currentDate.getFullYear();

    if (year < currentYear || (year === currentYear && month < currentMonth)) {
        return false;
    }

    return true;
}



function toggleNewCardFields(selectedCard) {
            const fields = ["credenziali", "numerocarta", "scadenzacarta", "cvv"];
            fields.forEach(field => {
                const inputField = document.getElementsByName(field)[0];
                if (selectedCard !== "") {
                    inputField.value = "";
                    inputField.disabled = true;
                } else {
                    inputField.disabled = false;
                }
            });
        }