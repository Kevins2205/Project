function hideElement() {
            setTimeout(() => {
                document.getElementById('img-check').classList.add('hidden');
            }, 1000); // 1000 millisecondi = 1 secondo
        }