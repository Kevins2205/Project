function validateForm() {
    const form = document.forms["quantita-prodotto"];
    const quantitaInput = form["quantita"];
    const quantita = quantitaInput.value.trim();

    const max = quantitaInput.max;
    const maxInt = parseInt(max, 10);
   
    const quantitaMessage = document.getElementById('nome-error');
    quantitaMessage.innerHTML = '';

    let isValid = true;

    if (!quantita) {
        quantitaMessage.innerHTML = '<h5>Devi inserire una quantità</h5>';
        isValid = false;
    } else if (isNaN(quantita) || parseInt(quantita) < 1 || parseInt(quantita) > maxInt) {
        quantitaMessage.innerHTML = '<h5>La quantità disponibile è ' + max + ' unità</h5>';
        isValid = false;
    }

    // Se non è valido, blocca l'invio del form
    if (!isValid) {
        return false;
    }

    return true;
}
