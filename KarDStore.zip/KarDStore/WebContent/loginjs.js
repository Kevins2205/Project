function validateForm() {
    const username = document.forms["form-login"]["username"].value.trim();
    const password = document.forms["form-login"]["password"].value.trim();
    const errorMessage = document.getElementById('login-error');

    errorMessage.innerHTML = ''; // Resetta il messaggio di errore
	var i=0;
    if (username === '') {
        errorMessage.innerHTML = '<h4>Il campo Username è obbligatorio.</h4>';
        i++;
    }

    if (password === '') {
        errorMessage.innerHTML = '<h4>Il campo Password è obbligatorio.</h4>';
		i++;
    }
    if(i==1){
		return false;
	}
	if(i>1){
		errorMessage.innerHTML = '<h4>Riempire i campi mancanti.</h4>';
		return false;
	}
    

	errorMessage.innerHTML = '';
    return true; // Se tutti i campi sono validi, consenti l'invio del form
}

