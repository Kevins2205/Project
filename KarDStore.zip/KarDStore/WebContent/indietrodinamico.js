function saveScrollPosition() {
            localStorage.setItem('scrollPosition', window.scrollY);
        }

        function restoreScrollPosition() {
            const scrollPosition = localStorage.getItem('scrollPosition');
            if (scrollPosition !== null) {
                window.scrollTo(0, parseInt(scrollPosition));
            }
        }

        function hideElement() {
            setTimeout(() => {
                const checkMark = document.getElementById('img-check');
                if (checkMark) {
                    checkMark.classList.add('scompari');
                }
            }, 500); // 1000 millisecondi = 1 secondo
        }

        function saveScrollPositionAdd() {
            saveScrollPosition();
            hideElement();
        }

        document.addEventListener('DOMContentLoaded', (event) => {
            restoreScrollPosition();
            hideElement();
        });
        
        
        function confirmDelete() {
    return confirm("Sei sicuro di voler eliminare questo prodotto?");
}



function hideAddToCartForAdmin(role) {
    if (role === 'amministratore') {
        let addToCartButtons = document.getElementsByClassName('add-to-cart');
        for (let button of addToCartButtons) {
            button.style.display = 'none';
        }
    }
}

        