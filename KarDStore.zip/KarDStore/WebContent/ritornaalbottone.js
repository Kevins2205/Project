function saveScrollPositionAdd() {
        localStorage.setItem('scrollPosition', window.scrollY);
    }

    function restoreScrollPosition() {
        const scrollPosition = localStorage.getItem('scrollPosition');
        if (scrollPosition !== null) {
            window.scrollTo(0, parseInt(scrollPosition));
        }
    }

    document.addEventListener('DOMContentLoaded', (event) => {
        restoreScrollPosition();
    });