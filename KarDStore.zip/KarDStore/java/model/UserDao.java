package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;


public class UserDao {
	public static ArrayList<User> getUsernameUtenti() {
		User u=null;
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        ArrayList<User> utenti= new ArrayList<User>();
        try {
            con = ConDB.Connessione(); // Metodo per ottenere la connessione al database
            String sql = "SELECT * FROM utente WHERE tipo = 'cliente'";
            ps = con.prepareStatement(sql);
           
            rs = ps.executeQuery();

            while (rs.next()) {
            	
		   		u= new User();
		   				u.setUsername(rs.getString("username"));
		   				u.setNome(rs.getString("nome"));
		   				u.setCognome(rs.getString("cognome"));
		   				u.setEmail(rs.getString("email"));
		   				u.setPw(rs.getString("pw"));
		   				u.setCitt�(rs.getString("citta"));
		   				u.setTel(rs.getString("tel"));
		   				u.setCap(rs.getString("cap"));
		   				u.setData_nascita(rs.getString("data_nascita"));
		   				u.setVia(rs.getString("via"));

		   				utenti.add(u);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // Gestione dell'eccezione
        } finally {
            ConDB.releaseConnection(con); // Metodo per rilasciare la connessione
        }

        return utenti;
    }
}
