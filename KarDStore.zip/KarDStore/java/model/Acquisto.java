package model;

public class Acquisto {
	private int codice_prodotto;
	private int codice_ordine;
	private float prezzo_all_acquisto;
	private float iva_all_acquisto;
	private int quantit�;
	private String nome_prodotto;
	private String foto_prodotto;
	
	public int getCodice_prodotto() {
		return codice_prodotto;
	}
	public void setCodice_prodotto(int codice_prodotto) {
		this.codice_prodotto = codice_prodotto;
	}
	public int getCodice_ordine() {
		return codice_ordine;
	}
	public void setCodice_ordine(int codice_ordine) {
		this.codice_ordine = codice_ordine;
	}
	public float getPrezzo_all_acquisto() {
		return prezzo_all_acquisto;
	}
	public void setPrezzo_all_acquisto(float prezzo_all_acquisto) {
		this.prezzo_all_acquisto = prezzo_all_acquisto;
	}
	public float getIva_all_acquisto() {
		return iva_all_acquisto;
	}
	public void setIva_all_acquisto(float iva_all_acquisto) {
		this.iva_all_acquisto = iva_all_acquisto;
	}
	public int getQuantit�() {
		return quantit�;
	}
	public void setQuantit�(int quantit�) {
		this.quantit� = quantit�;
	}
	public String getNome_prodotto() {
		return nome_prodotto;
	}
	public void setNome_prodotto(String nome_prodotto) {
		this.nome_prodotto = nome_prodotto;
	}
	public String getFoto_prodotto() {
		return foto_prodotto;
	}
	public void setFoto_prodotto(String foto_prodotto) {
		this.foto_prodotto = foto_prodotto;
	}
	
	
}
