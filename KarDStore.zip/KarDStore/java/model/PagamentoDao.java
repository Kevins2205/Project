package model;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class PagamentoDao {
	public static void addMetodoPagamento(Pagamento p){
		
		 PreparedStatement preparedStatement = null;
		    Connection connessione = null;

		    try {
		        connessione = ConDB.Connessione();
		        if (connessione == null) {
		            throw new SQLException("Failed to connect to database");
		        }

		        String query = "INSERT INTO pagamento (numero_carta, username_utente, data_scadenza, credenziali_carta, cvv) " +
		                       "VALUES (?,?,?,?,?)";
		        preparedStatement = connessione.prepareStatement(query);
		        preparedStatement.setString(1, p.getNumero_carta());
		        preparedStatement.setString(2, p.getUsername_utente());
		        preparedStatement.setString(3, p.getData_scadenza());
		        preparedStatement.setString(4, p.getCredenziali_carta());
		        preparedStatement.setInt(5, p.getCvv());
		        // Log dei valori per debug
		        System.out.println("numero_carta: " + p.getNumero_carta());
		        System.out.println("username_utente: " + p.getUsername_utente());
		        System.out.println("data_scadenza: " + p.getData_scadenza());
		        System.out.println("credenziali_carta: " + p.getCredenziali_carta());
		        System.out.println("cvv: " + p.getCvv());
		        

		       
		       
		       
		            int rowsInserted = preparedStatement.executeUpdate();
		            connessione.commit();
		            System.out.println("righe inserite: " + rowsInserted);
		    }
		     catch (SQLException e) {
		        e.printStackTrace();
		    } finally {
		        try {
		           if (preparedStatement != null) preparedStatement.close();
		        } catch (SQLException sqlException) {
		            System.out.println(sqlException);
		        } finally {
		            if (connessione != null) ConDB.releaseConnection(connessione);
		        }
		    }
		
		
	}
	
	
	
	
	public static List<Pagamento> getMetodiPagamentoByUsername(String username) {
        List<Pagamento> metodiPagamento = new ArrayList<>();
        Connection connessione = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        try {
            connessione = ConDB.Connessione();
            String query = "SELECT numero_carta, data_scadenza, credenziali_carta, cvv FROM pagamento WHERE username_utente = ?";
            preparedStatement = connessione.prepareStatement(query);
            preparedStatement.setString(1, username);
            resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                Pagamento pagamento = new Pagamento();
                pagamento.setNumero_carta(resultSet.getString("numero_carta"));
                pagamento.setData_scadenza(resultSet.getString("data_scadenza"));
                pagamento.setCredenziali_carta(resultSet.getString("credenziali_carta"));
                pagamento.setCvv(resultSet.getInt("cvv"));
                metodiPagamento.add(pagamento);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (resultSet != null) resultSet.close();
                if (preparedStatement != null) preparedStatement.close();
            } catch (SQLException sqlException) {
                System.out.println(sqlException);
            } finally {
                if (connessione != null) ConDB.releaseConnection(connessione);
            }
        }

        return metodiPagamento;
    }
	
	
	
	

	public static boolean contains(String nc) {
       
        Connection connessione = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        boolean trovato=false;
        try {
            connessione = ConDB.Connessione();
            String query = "SELECT numero_carta, data_scadenza, credenziali_carta, cvv FROM pagamento WHERE numero_carta = ?";
            preparedStatement = connessione.prepareStatement(query);
            preparedStatement.setString(1, nc);
            resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
               trovato=true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (resultSet != null) resultSet.close();
                if (preparedStatement != null) preparedStatement.close();
            } catch (SQLException sqlException) {
                System.out.println(sqlException);
            } finally {
                if (connessione != null) ConDB.releaseConnection(connessione);
            }
        }

        return trovato;
    }
	
	
	
	
}
