package model;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import javax.imageio.ImageIO;

public class FatturaDao {
    public static String CreaFattura(ArrayList<Acquisto> a, Ordine o, Pagamento p) {
        String filePath = null;
        
        try {
            // Caricare l'immagine esistente
            BufferedImage originalImage = ImageIO.read(new File("C:\\Users\\kevin\\Downloads\\fattura-vuota.jpeg"));

            // Creare una nuova immagine con lo stesso contenuto dell'originale
            BufferedImage modifiedImage = new BufferedImage(originalImage.getWidth(), originalImage.getHeight(), BufferedImage.TYPE_INT_RGB);
            Graphics g = modifiedImage.getGraphics();
            g.drawImage(originalImage, 0, 0, null);

            // Impostare il colore del testo
            g.setColor(Color.black);

            // Impostare il font
            Font font = new Font("Serif", Font.BOLD, 40);
            g.setFont(font);

            // Impostare il font per i campi di dettaglio (un po' pi� piccolo)
            Font detailFont = new Font("Serif", Font.PLAIN, 30);
            g.setFont(detailFont);

            // Disegnare i dettagli della fattura
            int y = 200; // y iniziale per i dettagli della fattura
            g.drawString("" + "**** **** **** " + p.getNumero_carta().substring(13), 850, y);
            y += 220;
            g.drawString("" + p.getCredenziali_carta(), 200, y);
            y += 30;
            g.drawString("" + o.getData_ordine(), 950, y);
            y+=35;
            g.drawString("" + o.getData_ordine(), 950, y);
            y += 60;
            g.drawString("" + o.getPrezzo_totale() + "�", 900, y);
            

            // Impostare il font per i prodotti (un po' pi� piccolo)
            g.setFont(detailFont);

            // Posizione y per la lista dei prodotti
            y = 880;
            for (Acquisto acquisto : a) {
                String nomeProdotto = acquisto.getNome_prodotto();
                String quantity = "" + acquisto.getQuantit�();
                double prezzo=acquisto.getPrezzo_all_acquisto()+((acquisto.getIva_all_acquisto()*acquisto.getPrezzo_all_acquisto())/100);
                double newprezzo=Math.round(prezzo * 100.0) / 100.0;
                
                
                String prezzosingolo="" + acquisto.getPrezzo_all_acquisto();
                
				
				
				
                
                
                String prezzoSingolo = prezzosingolo + "� + " + acquisto.getIva_all_acquisto() + "% di IVA";
                double totprd = acquisto.getQuantit�() * (newprezzo);

                double newtotprd = Math.round(totprd * 100.0) / 100.0;
                String totaleProdotto = "" + newtotprd + "�";
                if(nomeProdotto.length()>27) {
                	
                	String newnome=nomeProdotto.substring(0, 27)+" ...";
                	g.drawString(newnome, 80, y);
                }
                else {
                	g.drawString(nomeProdotto, 80, y);
                }
                // Disegnare il testo sull'immagine
                
                g.drawString(quantity, 560, y);
                g.drawString(prezzoSingolo, 650, y);
                g.drawString(totaleProdotto, 1020, y);
                
                y += 50; // incrementare y per la prossima riga di prodotti
            }

            // Rilascia le risorse grafiche
            g.dispose();

            // Salvare l'immagine modificata su disco
            filePath = "C:\\Users\\kevin\\Downloads\\fattura_" + o.getId() + ".jpeg";
            ImageIO.write(modifiedImage, "jpeg", new File(filePath));

        } catch (IOException e) {
            e.printStackTrace();
        }
        return filePath;
    }
}
