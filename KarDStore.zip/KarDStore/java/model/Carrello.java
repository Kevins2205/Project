package model;

public class Carrello {
	private int id; 
	private String username_utente;
	private int codice_prodotto;
	private int quantit�;
	public Carrello() {

		
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getUsername_utente() {
		return username_utente;
	}
	public void setUsername_utente(String username_utente) {
		this.username_utente = username_utente;
	}
	public int getCodice_prodotto() {
		return codice_prodotto;
	}
	public void setCodice_prodotto(int codice_prodotto) {
		this.codice_prodotto = codice_prodotto;
	}
	public int getQuantit�() {
		return quantit�;
	}
	public void setQuantit�(int quantit�) {
		this.quantit� = quantit�;
	}
	
	
	
}
