package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Base64;

public class AcquistoDao {
	public static void addAcquisto(Acquisto acquisto) {
		PreparedStatement ps = null;
       
        Connection connessione= null;
        try {
    		 connessione= ConDB.Connessione();
			String query ="INSERT INTO acquisto (codice_prodotto, codice_ordine, prezzo_all_acquisto, iva_all_acquisto, quantita, nome_prodotto, foto_prodotto) " +
                    "VALUES (?, ?, ?, ?, ?, ?, ?)";
			ps = connessione.prepareStatement(query);
			ps.setInt(1, acquisto.getCodice_prodotto());
			ps.setInt(2, acquisto.getCodice_ordine());
			ps.setFloat(3, acquisto.getPrezzo_all_acquisto());
			ps.setFloat(4, acquisto.getIva_all_acquisto());
			ps.setInt(5, acquisto.getQuantit�());
			ps.setString(6, acquisto.getNome_prodotto());
			
			byte[] foto= Base64.getDecoder().decode(acquisto.getFoto_prodotto());
			
			ps.setBytes(7, foto);
	        ps.executeUpdate();
	        connessione.commit();
		 // Chiudiamo le risorse
           
           
    		} 
        catch (Exception e) {
            e.printStackTrace();
        	}finally {
    	        try {
    	            if (ps != null) ps.close();
    	        } catch (SQLException sqlException) {
    	            System.out.println(sqlException);
    	        } finally {
    	            if (connessione != null) ConDB.releaseConnection(connessione);
    	        }
        	}
        
	}
	public static ArrayList<Acquisto> getAcquistiByOrdine(int ordine) {
		Acquisto a=null;
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        ArrayList<Acquisto> acquisti= new ArrayList<Acquisto>();
        try {
            con = ConDB.Connessione(); // Metodo per ottenere la connessione al database
            String sql = "SELECT * FROM acquisto WHERE codice_ordine = ?";
            ps = con.prepareStatement(sql);
            ps.setInt(1, ordine);
            rs = ps.executeQuery();

            while (rs.next()) {
            	
		   		a= new Acquisto();
		   		a.setCodice_prodotto(rs.getInt("codice_prodotto"));
		   		a.setCodice_ordine(ordine);
		   		a.setPrezzo_all_acquisto(rs.getFloat("prezzo_all_acquisto"));
		   		a.setIva_all_acquisto(rs.getFloat("iva_all_acquisto"));
		   		a.setQuantit�(rs.getInt("quantita"));
		   		a.setNome_prodotto(rs.getString("nome_prodotto"));
		   		a.setFoto_prodotto(rs.getString("foto_prodotto"));
		   		
   				acquisti.add(a);
            }
            con.commit();
        } catch (SQLException e) {
            e.printStackTrace();
            // Gestione dell'eccezione
        } finally {
	        try {
	            if (ps != null) ps.close();
	            if(rs!= null) rs.close();
	        } catch (SQLException sqlException) {
	            System.out.println(sqlException);
	        } finally {
	            if (con != null) ConDB.releaseConnection(con);
	        }
    	}

        return acquisti;
    }
	
	
	
	
        

	
}
