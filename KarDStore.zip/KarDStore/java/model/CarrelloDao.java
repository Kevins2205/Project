package model;
import java.sql.*;
	import java.util.ArrayList;
	import java.util.List;


import model.ConDB;
public class CarrelloDao {
	

	
	    private Connection connection;

	    public CarrelloDao() {
	       
	    }

	    public void addItem(Carrello item) throws SQLException {
	    	
			PreparedStatement stmt = null;
	    	try {
	            
	            connection = ConDB.Connessione();
	        } catch (SQLException e) {
	            throw new SQLException("connessione fallita", e);
	        }
	        String query = "INSERT INTO carrello (username_utente, codice_prodotto, quantita) VALUES (?, ?, ?)";
	        try  {
	        	stmt = connection.prepareStatement(query);
	            stmt.setString(1, item.getUsername_utente());
	            stmt.setInt(2, item.getCodice_prodotto());
	            stmt.setInt(3, item.getQuantit�());
	            System.out.println("Executing query: " + stmt.toString());

	            // Execute the query
	            int rowsAffected = stmt.executeUpdate();
	            
	            // Log the number of rows affected
	            System.out.println("Rows affected: " + rowsAffected);
	            
	            // Check if any rows were inserted
	            if (rowsAffected == 0) {
	                throw new SQLException("Inserting item failed, no rows affected.");
	            }
	            //stmt.executeUpdate();
	        }catch (SQLException e) {
	            e.printStackTrace();
	            throw e;
	        } finally {
				try {
					if (stmt != null)
						stmt.close();
				} catch (SQLException sqlException) {
					System.out.println(sqlException);
				} finally {
					if (connection != null) {
						 connection.commit();
						 ConDB.releaseConnection(connection);
					}
						
				}
			}
	       
	    }
	    
	    
	    
	    
	    
	    
	    
	    
	    public List<Carrello> getCarrello(String usernameUtente) throws SQLException {
	    	
			PreparedStatement statement = null;
	    	try {
	            
	            connection = ConDB.Connessione();
	        } catch (SQLException e) {
	            throw new SQLException("connessione fallita", e);
	        }
	        List<Carrello> carrelloList = new ArrayList<>();
	        String sql = "SELECT * FROM carrello WHERE username_utente = ?";
	        
	        try {
	        	statement = connection.prepareStatement(sql);
	            statement.setString(1, usernameUtente);
	            
	            // Print the SQL query for debugging
	            System.out.println("Executing query: " + statement.toString());

	            try (ResultSet resultSet = statement.executeQuery() ) {
	                while (resultSet.next()) {
	                    Carrello item = new Carrello();
	                    item.setId(resultSet.getInt("id"));
	                    item.setUsername_utente(resultSet.getString("username_utente"));
	                    item.setCodice_prodotto(resultSet.getInt("codice_prodotto"));
	                    item.setQuantit�(resultSet.getInt("quantita"));
	                    carrelloList.add(item);
	                }
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	            throw e;
	        } finally {
				try {
					if (statement != null)
						statement.close();
				} catch (SQLException sqlException) {
					System.out.println(sqlException);
				} finally {
					if (connection != null) {
						 connection.commit();
						 ConDB.releaseConnection(connection);
					}
						
				}
			}
	       
	        // Log the result
	        System.out.println("Retrieved cart items: " + carrelloList);
	        return carrelloList;
	    }


	    public void updateItem(int quantit�, int idItem, String usr) throws SQLException {
	    	
			PreparedStatement stmt = null;
	    	try {
	            
	            connection = ConDB.Connessione();
	        } catch (SQLException e) {
	            throw new SQLException("connessione fallita", e);
	        }
	    	String query = "UPDATE carrello SET quantita = ? WHERE codice_prodotto = ? AND username_utente=?";
	       
	        try {
	        	stmt = connection.prepareStatement(query);
	        	 System.out.println("Executing query: " + stmt.toString());
	            stmt.setInt(1, quantit�);
	            stmt.setInt(2, idItem);
	            stmt.setString(3, usr);
	            stmt.executeUpdate();
	            connection.commit();
	        }catch (SQLException e) {
	            e.printStackTrace();
	            throw e;
	        }finally {
				try {
					if (stmt != null)
						stmt.close();
				} catch (SQLException sqlException) {
					System.out.println(sqlException);
				} finally {
					if (connection != null)
						ConDB.releaseConnection(connection);
				}
			}
	    }

	    public void removeItem(int itemId, String Usernameutente) throws SQLException {
	    	
			PreparedStatement stmt = null;
	    	try {
	            
	            connection = ConDB.Connessione();
	        } catch (SQLException e) {
	            throw new SQLException("connessione fallita", e);
	        }
	        String query = "DELETE FROM carrello WHERE codice_prodotto = ? AND username_utente= ?";
	        try {
	        	stmt = connection.prepareStatement(query);
	        	 System.out.println("Executing query: " + stmt.toString());
	            stmt.setInt(1, itemId);
	            stmt.setString(2, Usernameutente);
	            stmt.executeUpdate();
	            connection.commit();
	        } catch (SQLException e) {
	            e.printStackTrace();
	            throw e;
	        }finally {
				try {
					if (stmt != null)
						stmt.close();
				} catch (SQLException sqlException) {
					System.out.println(sqlException);
				} finally {
					if (connection != null)
						ConDB.releaseConnection(connection);
				}
			}
	    }

	    public void clearCart(String Username_utente) throws SQLException {
	    	
			PreparedStatement stmt = null;
			try {
	            
	            connection = ConDB.Connessione();
	        } catch (SQLException e) {
	            throw new SQLException("connessione fallita", e);
	        }
	    	String query = "DELETE FROM carrello WHERE username_utente = ?";
	        try {
	        	stmt = connection.prepareStatement(query);
	            stmt.setString(1, Username_utente);
	            System.out.println("Executing query: " + stmt.toString());
	            stmt.executeUpdate();
	           
	        }catch(SQLException e) {
	        	e.printStackTrace();
	            throw e;
	        }
	        
	        finally {
				try {
					if (stmt != null)
						stmt.close();
				} catch (SQLException sqlException) {
					System.out.println(sqlException);
				} finally {
					if (connection != null)
						 connection.commit();
						ConDB.releaseConnection(connection);
				}
			}
	    }
	}

