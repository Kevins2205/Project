package model;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;
import java.util.Base64;
public class ProdottoDao {
	
	public static ArrayList<Prodotto> inserimentoProdotti() {
		ArrayList<Prodotto> prodotti = new ArrayList<Prodotto>();
		
        try {
    		Connection connessione= ConDB.Connessione();
			String query ="SELECT * FROM prodotto";
			PreparedStatement preparedStatement = connessione.prepareStatement(query);
	        ResultSet rs = preparedStatement.executeQuery();

		   	while(rs.next()) //int id, String descrizione, float prezzo, float iva, byte[] img, String tipo, String categoria
			{
		   		byte[] b=rs.getBytes("foto");
		   		if(b==null) continue;
		   		String foto=Base64.getEncoder().encodeToString(b);
		   		Prodotto p= new Prodotto(
		   				rs.getInt("id"),
		   				rs.getString("nome"),
		   				rs.getString("descrizione"),
		   				rs.getFloat("prezzo"),
		   				rs.getFloat("iva"),
		   				foto,
		   				rs.getString("tipo"),
		   				rs.getString("categoria"),
		   				rs.getInt("quantita_disponibile")
		   				);
		   		prodotti.add(p);
				
			}
		 // Chiudiamo le risorse
            rs.close();
            preparedStatement.close();
    		} 
        catch (Exception e) {
            e.printStackTrace();
        	}
        return prodotti;
	}
	
	
	
	
	public static void addProdotto(Prodotto p, String img) {
	    PreparedStatement preparedStatement = null;
	    Connection connessione = null;

	    try {
	        connessione = ConDB.Connessione();
	        if (connessione == null) {
	            throw new SQLException("Failed to connect to database");
	        }

	        String query = "INSERT INTO prodotto (nome, descrizione, prezzo, iva, foto, tipo, categoria, quantita_disponibile) " +
	                       "VALUES (?,?,?,?,?,?,?,?)";
	        preparedStatement = connessione.prepareStatement(query);
	        preparedStatement.setString(1, p.getNome());
	        preparedStatement.setString(2, p.getDescrizione());
	        preparedStatement.setFloat(3, p.getPrezzo());
	        preparedStatement.setFloat(4, p.getIva());
	        
	        // Log dei valori per debug
	        System.out.println("Nome: " + p.getNome());
	        System.out.println("Descrizione: " + p.getDescrizione());
	        System.out.println("Prezzo: " + p.getPrezzo());
	        System.out.println("IVA: " + p.getIva());
	        System.out.println("Foto Path: " + img);
	        System.out.println("Tipo: " + p.getTipo());
	        System.out.println("Categoria: " + p.getCategoria());
	        System.out.println("Quantit� Disponibile: " + p.getQuantita_disponibile());

	        preparedStatement.setString(6, p.getTipo());
	        preparedStatement.setString(7, p.getCategoria());
	        preparedStatement.setInt(8, p.getQuantita_disponibile());

	        File file = new File(img);
	        try (FileInputStream fis = new FileInputStream(file)) {
	            preparedStatement.setBinaryStream(5, fis, (int) file.length());
	            int rowsInserted = preparedStatement.executeUpdate();
	            connessione.commit();
	            System.out.println("righe inserite: " + rowsInserted);
	        } catch (FileNotFoundException e) {
	            System.out.println(e);
	        } catch (IOException e) {
	            System.out.println(e);
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    } finally {
	        try {
	            if (preparedStatement != null) preparedStatement.close();
	        } catch (SQLException sqlException) {
	            System.out.println(sqlException);
	        } finally {
	            if (connessione != null) ConDB.releaseConnection(connessione);
	        }
	    }
	}

	
	
	
	public static Prodotto getProdottoById(int id) {
		Prodotto p=null;
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            con = ConDB.Connessione(); // Metodo per ottenere la connessione al database
            String sql = "SELECT * FROM prodotto WHERE id = ?";
            ps = con.prepareStatement(sql);
            ps.setInt(1, id);
            rs = ps.executeQuery();

            if (rs.next()) {
            	byte[] b=rs.getBytes("foto");
		   		if(b==null) return null;
		   		String foto=Base64.getEncoder().encodeToString(b);
		   		p= new Prodotto(
		   				rs.getInt("id"),
		   				rs.getString("nome"),
		   				rs.getString("descrizione"),
		   				rs.getFloat("prezzo"),
		   				rs.getFloat("iva"),
		   				foto,
		   				rs.getString("tipo"),
		   				rs.getString("categoria"),
		   				rs.getInt("quantita_disponibile")
		   				);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // Gestione dell'eccezione
        } finally {
            ConDB.releaseConnection(con); // Metodo per rilasciare la connessione
        }

        return p;
    }
	
	
	public static ArrayList<Prodotto> getProdottiByCategoria(String categoria) {
	 	ArrayList <Prodotto> p=null;
	 	Prodotto pro = null;
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            con = ConDB.Connessione(); // Metodo per ottenere la connessione al database
            String sql = "SELECT * FROM prodotto WHERE categoria = ?";
            ps = con.prepareStatement(sql);
            ps.setString(1, categoria);
            rs = ps.executeQuery();
            p = new ArrayList <Prodotto>();
            while (rs.next()) {
            
            	byte[] b=rs.getBytes("foto");
		   		if(b==null) return null;
		   		String foto=Base64.getEncoder().encodeToString(b);
		   		pro= new Prodotto(
		   				rs.getInt("id"),
		   				rs.getString("nome"),
		   				rs.getString("descrizione"),
		   				rs.getFloat("prezzo"),
		   				rs.getFloat("iva"),
		   				foto,
		   				rs.getString("tipo"),
		   				rs.getString("categoria"),
		   				rs.getInt("quantita_disponibile")
		   				);
		   		p.add(pro);
            }
 
        }
            catch (SQLException e) {
            e.printStackTrace();
            // Gestione dell'eccezione
        } finally {
            ConDB.releaseConnection(con); // Metodo per rilasciare la connessione
        }

        return p;
	}
	
	public static ArrayList<Prodotto> searchProdotti(String query) {
	    ArrayList<Prodotto> prodotti = new ArrayList<Prodotto>();
	    try {
	        Connection connessione = ConDB.Connessione();
	        String sql = "SELECT * FROM prodotto WHERE nome LIKE ?";
	        PreparedStatement preparedStatement = connessione.prepareStatement(sql);
	        preparedStatement.setString(1, "%" + query + "%");
	        
	        ResultSet rs = preparedStatement.executeQuery();
	        
	        while (rs.next()) {
	            byte[] b = rs.getBytes("foto");
	            if (b == null) continue;
	            String foto = Base64.getEncoder().encodeToString(b);
	            Prodotto p = new Prodotto(
	                rs.getInt("id"),
	                rs.getString("nome"),
	                rs.getString("descrizione"),
	                rs.getFloat("prezzo"),
	                rs.getFloat("iva"),
	                foto,
	                rs.getString("tipo"),
	                rs.getString("categoria"),
	                rs.getInt("quantita_disponibile")
	            );
	            prodotti.add(p);
	            System.out.println("Prodotto trovato: " + p.getNome()); // Debug
	        }

	        rs.close();
	        preparedStatement.close();
	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	   
	    return prodotti;
	    
	    
	}











public static void updateQuantit�(int quantit�, Prodotto p) throws SQLException {
	
	PreparedStatement stmt = null;
	Connection connection=null;
	try {
        
        connection = ConDB.Connessione();
    } catch (SQLException e) {
        throw new SQLException("connessione fallita", e);
    }
	String query = "UPDATE prodotto SET quantita_disponibile = ? WHERE id = ? ";
   
    try {
    	stmt = connection.prepareStatement(query);
    	 System.out.println("Executing query: " + stmt.toString());
        int q= p.getQuantita_disponibile()-quantit�;
    	 stmt.setInt(1, q);
        stmt.setInt(2, p.getId());
      
        stmt.executeUpdate();
        connection.commit();
    }catch (SQLException e) {
        e.printStackTrace();
        throw e;
    }finally {
		try {
			if (stmt != null)
				stmt.close();
		} catch (SQLException sqlException) {
			System.out.println(sqlException);
		} finally {
			if (connection != null)
				ConDB.releaseConnection(connection);
		}
	}
}





public static void updateProdotto(Prodotto prodotto) {
    Connection connection = null;
    PreparedStatement stmt = null;

    try {
        connection = ConDB.Connessione();
        String query = "UPDATE prodotto SET nome = ?, descrizione = ?, prezzo = ?, iva = ?, quantita_disponibile = ? WHERE id = ?";
        stmt = connection.prepareStatement(query);
        stmt.setString(1, prodotto.getNome());
        stmt.setString(2, prodotto.getDescrizione());
        stmt.setFloat(3, prodotto.getPrezzo());
        stmt.setFloat(4, prodotto.getIva());
        stmt.setInt(5, prodotto.getQuantita_disponibile());
        stmt.setInt(6, prodotto.getId());
        stmt.executeUpdate();
        connection.commit();
    } catch (SQLException e) {
        e.printStackTrace();
    } finally {
        if (stmt != null) {
            try {
                stmt.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        if (connection != null) {
            ConDB.releaseConnection(connection);
        }
    }
}








public static void removeProdotto(int id) throws SQLException {
    Connection connection = null;
    PreparedStatement stmt = null;

    try {
        connection = ConDB.Connessione();
        String query = "DELETE FROM prodotto WHERE id = ?";
        stmt = connection.prepareStatement(query);
        stmt.setInt(1, id);
        stmt.executeUpdate();
        connection.commit();
    } catch (SQLException e) {
        e.printStackTrace();
        throw e;
    } finally {
        if (stmt != null) stmt.close();
        if (connection != null) ConDB.releaseConnection(connection);
    }
}


}


