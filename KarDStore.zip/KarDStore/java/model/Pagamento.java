package model;

public class Pagamento {
	private String numero_carta;
	private String username_utente;
	private String data_scadenza;
	private String credenziali_carta;
	private int cvv;
	public String getNumero_carta() {
		return numero_carta;
	}
	public void setNumero_carta(String numero_carta) {
		this.numero_carta = numero_carta;
	}
	public String getUsername_utente() {
		return username_utente;
	}
	public void setUsername_utente(String username_utente) {
		this.username_utente = username_utente;
	}
	public String getData_scadenza() {
		return data_scadenza;
	}
	public void setData_scadenza(String data_scadenza) {
		this.data_scadenza = data_scadenza;
	}
	public String getCredenziali_carta() {
		return credenziali_carta;
	}
	public void setCredenziali_carta(String credenziali_carta) {
		this.credenziali_carta = credenziali_carta;
	}
	public int getCvv() {
		return cvv;
	}
	public void setCvv(int cvv) {
		this.cvv = cvv;
	}
	
}
