package model;

public class Prodotto {
	private int id; 
	private String descrizione;
	private String nome;
	private float prezzo;
	private float iva;
	private int quantita_disponibile;
	private String tipo; /*fare controllo sulla categoria
	categoria=pokemon
	tipo= carta singola, mazzo, bustina, tin, box
	
	categoria=dragon ball
	tipo= lamin card, mazzo, bustina, box
	
	categoria=magic
	tipo= carta singola, mazzo, bustina, box
	
	categoria=yu-gi-oh!
	tipo= carta singola, mazzo, bustina, tin, box
	
	*
	*/ 
	private String categoria;// dragon ball, yu-gi-oh!, pokemon, magic
	private String img;
	
	public Prodotto(int id, String nome,String descrizione, float prezzo, float iva, String img, String tipo, String categoria, int quantita_disponibile) {
		this.id = id;
		this.nome=nome;
		this.descrizione = descrizione;
		this.prezzo = prezzo;
		this.iva = iva;
		this.categoria = categoria;
		if(categoria.equals("pokemon"))
		{
			if(tipo.equalsIgnoreCase("carta singola") || tipo.equalsIgnoreCase("mazzo") || tipo.equalsIgnoreCase("bustina") || tipo.equalsIgnoreCase("tin") ||tipo.equalsIgnoreCase("box"))
			this.tipo = tipo;
		}
		else if(categoria.equals("dragon ball"))
		{
			if(tipo.equalsIgnoreCase("lamin card") || tipo.equalsIgnoreCase("mazzo") || tipo.equalsIgnoreCase("bustina") ||tipo.equalsIgnoreCase("box"))
			this.tipo = tipo;
		}
		else if(categoria.equals("magic"))
		{
			if(tipo.equalsIgnoreCase("carta singola") || tipo.equalsIgnoreCase("mazzo") || tipo.equalsIgnoreCase("bustina") ||tipo.equalsIgnoreCase("box"))
			this.tipo = tipo;
		}
		else if(categoria.equals("yu-gi-oh!"))
		{
			if(tipo.equalsIgnoreCase("carta singola") || tipo.equalsIgnoreCase("mazzo") || tipo.equalsIgnoreCase("bustina") || tipo.equalsIgnoreCase("tin") ||tipo.equalsIgnoreCase("box"))
			this.tipo = tipo;
		}
		this.img = img;
		this.quantita_disponibile=quantita_disponibile;
	}

	
	
	public Prodotto( String nome,String descrizione, float prezzo, float iva,  String tipo, String categoria, int quantita_disponibile) {
		
		
		this.nome=nome;
		this.descrizione = descrizione;
		this.prezzo = prezzo;
		this.iva = iva;
		this.categoria = categoria;
		if(categoria.equals("pokemon"))
		{
			if(tipo.equalsIgnoreCase("carta singola") || tipo.equalsIgnoreCase("mazzo") || tipo.equalsIgnoreCase("bustina") || tipo.equalsIgnoreCase("tin") ||tipo.equalsIgnoreCase("box"))
			this.tipo = tipo;
		}
		else if(categoria.equals("dragon ball"))
		{
			if(tipo.equalsIgnoreCase("lamin card") || tipo.equalsIgnoreCase("mazzo") || tipo.equalsIgnoreCase("bustina") ||tipo.equalsIgnoreCase("box"))
			this.tipo = tipo;
		}
		else if(categoria.equals("magic"))
		{
			if(tipo.equalsIgnoreCase("carta singola") || tipo.equalsIgnoreCase("mazzo") || tipo.equalsIgnoreCase("bustina") ||tipo.equalsIgnoreCase("box"))
			this.tipo = tipo;
		}
		else if(categoria.equals("yu-gi-oh!"))
		{
			if(tipo.equalsIgnoreCase("carta singola") || tipo.equalsIgnoreCase("mazzo") || tipo.equalsIgnoreCase("bustina") || tipo.equalsIgnoreCase("tin") ||tipo.equalsIgnoreCase("box"))
			this.tipo = tipo;
		}
		
		this.quantita_disponibile=quantita_disponibile;
	}
	
	
public Prodotto( String nome,String descrizione, float prezzo, float iva,  int quantita_disponibile) {
		
		
		this.nome=nome;
		this.descrizione = descrizione;
		this.prezzo = prezzo;
		this.iva = iva;
		
		
		this.quantita_disponibile=quantita_disponibile;
	}

	
	
	



	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	
	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getDescrizione() {
		return descrizione;
	}

	public void setDescrizione(String descrizione) {
		this.descrizione = descrizione;
	}

	public float getPrezzo() {
		return prezzo;
	}

	public void setPrezzo(float prezzo) {
		this.prezzo = prezzo;
	}

	public float getIva() {
		return iva;
	}

	public void setIva(float iva) {
		this.iva = iva;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	public String getCategoria() {
		return categoria;
	}

	public void setCategoria(String categoria) {
		this.categoria = categoria;
	}

	public String getImg() {
		return img;
	}

	public void setImg(String img) {
		this.img = img;
	}



	public int getQuantita_disponibile() {
		return quantita_disponibile;
	}



	public void setQuantita_disponibile(int quantita_disponibile) {
		this.quantita_disponibile = quantita_disponibile;
	}
	
}
