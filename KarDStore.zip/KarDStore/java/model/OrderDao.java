package model;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Base64;

import javax.servlet.http.Part;

public class OrderDao {
	
	
	/*  String sql = "INSERT INTO Ordine (codiceProdotto, emailCliente, prezzoTotale, quantity, dataAcquisto, data_consegna) " +
                     "VALUES (?, ?, ?, ?, CURRENT_DATE(), DATE_ADD(CURRENT_DATE(), INTERVAL 14 DAY))";*/
	
	public static void addOrdine(Ordine ordine) {
		PreparedStatement ps = null;
       
        try {
    		Connection connessione= ConDB.Connessione();
			String query ="INSERT INTO ordine (username_utente, cognome_consegna, nome_consegna, prezzo_totale, data_ordine, data_consegna_prevista, citta, via, cap, id) " +
                    "VALUES (?, ?, ?, ?, CURRENT_DATE(), DATE_ADD(CURRENT_DATE(), INTERVAL 14 DAY), ?, ?, ?,?)";
			ps = connessione.prepareStatement(query);
			ps.setString(1, ordine.getUsername_utente());
			ps.setString(2, ordine.getCognome_consegna());
			ps.setString(3, ordine.getNome_consegna());
			ps.setFloat(4, ordine.getPrezzo_totale());
			ps.setString(5, ordine.getCitt�());
			ps.setString(6, ordine.getVia());
			ps.setString(7, ordine.getCap());
			ps.setInt(8, ordine.getId());
			ordine.setData_ordine(LocalDate.now().toString());
			ordine.setData_consegna_prevista(LocalDate.now().plusDays(14).toString());
	       ps.executeUpdate();
	       connessione.commit();
		 // Chiudiamo le risorse
           
            ps.close();
    		} 
        catch (Exception e) {
            e.printStackTrace();
        	}
        
	}
	public static ArrayList<Ordine> getOrdiniByUsername(String username) {
		Ordine o=null;
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        ArrayList<Ordine> ordini= new ArrayList<Ordine>();
        try {
            con = ConDB.Connessione(); // Metodo per ottenere la connessione al database
            String sql = "SELECT * FROM ordine WHERE username_utente = ?";
            ps = con.prepareStatement(sql);
            ps.setString(1, username);
            rs = ps.executeQuery();

            while (rs.next()) {
            	
		   		o= new Ordine();
		   		o.setId(rs.getInt("id"));
		   		o.setUsername_utente(rs.getString("username_utente"));
		   		o.setCognome_consegna(rs.getString("cognome_consegna"));
		   		o.setNome_consegna(rs.getString("nome_consegna"));
		   		o.setPrezzo_totale(rs.getFloat("prezzo_totale"));
		   		o.setData_ordine(rs.getString("data_ordine"));
		   		o.setData_consegna_prevista(rs.getString("data_consegna_prevista"));
		   		String cons=rs.getString("data_consegna_effettuata");
		   		if(cons!=null) o.setData_consegna_effettuata(cons);
		   		o.setCitt�(rs.getString("citta"));
		   		o.setVia(rs.getString("via"));
		   		o.setCap(rs.getString("cap"));
		   		
   				ordini.add(o);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // Gestione dell'eccezione
        } finally {
            ConDB.releaseConnection(con); // Metodo per rilasciare la connessione
        }

        return ordini;
    }
	
	public static void setFatturaById(Ordine o, String img) {
		PreparedStatement ps = null;
		PreparedStatement ps2 = null;
		ResultSet rs=null;
        try {
    		Connection connessione= ConDB.Connessione();
    		
    		
			String query ="UPDATE ordine SET immagine_fattura = ? WHERE id = ?";
			
			ps = connessione.prepareStatement(query);
			
			File file = new File(img);
	        try (FileInputStream fis = new FileInputStream(file)) {
	            ps.setBinaryStream(1, fis, (int) file.length());
	            ps.setInt(2, o.getId());
	            
	            int rowsInserted = ps.executeUpdate();
	            connessione.commit();
	            System.out.println("righe inserite: " + rowsInserted);
	        } catch (FileNotFoundException e) {
	            System.out.println(e);
	        }
	        ps.close();
	        try {
	        	String query2 ="SELECT immagine_fattura FROM ordine WHERE id = ?";
	        	ps2=connessione.prepareStatement(query2);
	        	ps2.setInt(1, o.getId());
	        	rs=ps2.executeQuery();
	        	if(rs.next()) {
		        	byte[] b=rs.getBytes("immagine_fattura");
			   		if(b==null) return;
			   		String foto=Base64.getEncoder().encodeToString(b);
			   		o.setFattura(foto);
		   		
	        	}
	        }catch(SQLException e) {
	        	e.printStackTrace();
	        }
		
		 // Chiudiamo le risorse
           rs.close();
           
        }	 
        catch (Exception e) {
            e.printStackTrace();
        	}
        
	}
	
	
	
	public static ArrayList<Ordine> getOrdini() {
		Ordine o=null;
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        ArrayList<Ordine> ordini= new ArrayList<Ordine>();
        try {
            con = ConDB.Connessione(); // Metodo per ottenere la connessione al database
            String sql = "SELECT * FROM ordine";
            ps = con.prepareStatement(sql);
        
            rs = ps.executeQuery();

            while (rs.next()) {
            	
		   		o= new Ordine();
		   		o.setId(rs.getInt("id"));
		   		o.setUsername_utente(rs.getString("username_utente"));
		   		o.setCognome_consegna(rs.getString("cognome_consegna"));
		   		o.setNome_consegna(rs.getString("nome_consegna"));
		   		o.setPrezzo_totale(rs.getFloat("prezzo_totale"));
		   		o.setData_ordine(rs.getString("data_ordine"));
		   		o.setData_consegna_prevista(rs.getString("data_consegna_prevista"));
		   		String cons=rs.getString("data_consegna_effettuata");
		   		if(cons!=null) o.setData_consegna_effettuata(cons);
		   		o.setCitt�(rs.getString("citta"));
		   		o.setVia(rs.getString("via"));
		   		o.setCap(rs.getString("cap"));
		   		
   				ordini.add(o);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // Gestione dell'eccezione
        } finally {
            ConDB.releaseConnection(con); // Metodo per rilasciare la connessione
        }

        return ordini;
    }
	
	public static int getLastOrdine() {
		PreparedStatement ps = null;
        ResultSet rs = null;
        int ultimo=0;
        try {
    		Connection connessione= ConDB.Connessione();
			String query ="SELECT MAX(id) FROM ordine";
			ps = connessione.prepareStatement(query);
			rs=ps.executeQuery();
			if(rs.next()) {
				ultimo=rs.getInt(1);
				System.out.println("id ordine max funzione:"+ultimo);
			}
					 // Chiudiamo le risorse
			connessione.commit();
           rs.close();
            ps.close();
            
    		} 
        catch (Exception e) {
            e.printStackTrace();
        	}
		return ultimo;
        
	}
	
	
	
	 public static Ordine getOrdineById(int id) {
	        Ordine o = null;
	        Connection con = null;
	        PreparedStatement ps = null;
	        ResultSet rs = null;
	        try {
	            con = ConDB.Connessione();
	            String sql = "SELECT * FROM ordine WHERE id = ?";
	            ps = con.prepareStatement(sql);
	            ps.setInt(1, id);
	            rs = ps.executeQuery();

	            if (rs.next()) {
	                o = new Ordine();
	                o.setId(rs.getInt("id"));
	                o.setUsername_utente(rs.getString("username_utente"));
	                o.setCognome_consegna(rs.getString("cognome_consegna"));
	                o.setNome_consegna(rs.getString("nome_consegna"));
	                o.setPrezzo_totale(rs.getFloat("prezzo_totale"));
	                o.setData_ordine(rs.getString("data_ordine"));
	                o.setData_consegna_prevista(rs.getString("data_consegna_prevista"));
	                String cons = rs.getString("data_consegna_effettuata");
	                if (cons != null) o.setData_consegna_effettuata(cons);
	                o.setCitt�(rs.getString("citta"));
	                o.setVia(rs.getString("via"));
	                o.setCap(rs.getString("cap"));
	                o.setFattura(rs.getString("immagine_fattura")); // Assuming "immagine_fattura" column stores the base64 invoice
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        } finally {
	            ConDB.releaseConnection(con);
	        }

	        return o;
	    }
	
	
}
