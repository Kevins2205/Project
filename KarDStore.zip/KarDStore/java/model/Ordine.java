package model;



public class Ordine {
	
	private int id;
	private String username_utente;
	private String cognome_consegna;
	private String nome_consegna;
	private float prezzo_totale;
	private String data_ordine;
	private String data_consegna_prevista;
	private String data_consegna_effettuata;
	private String citt�;
	private String via;
	private String cap;
	private String fattura;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getUsername_utente() {
		return username_utente;
	}
	public void setUsername_utente(String username_utente) {
		this.username_utente = username_utente;
	}
	public String getCognome_consegna() {
		return cognome_consegna;
	}
	public void setCognome_consegna(String cognome_consegna) {
		this.cognome_consegna = cognome_consegna;
	}
	public String getNome_consegna() {
		return nome_consegna;
	}
	public void setNome_consegna(String nome_consegna) {
		this.nome_consegna = nome_consegna;
	}
	public float getPrezzo_totale() {
		return prezzo_totale;
	}
	public void setPrezzo_totale(float prezzo_totale) {
		this.prezzo_totale = prezzo_totale;
	}
	public String getData_ordine() {
		return data_ordine;
	}
	public void setData_ordine(String data_ordine) {
		this.data_ordine = data_ordine;
	}
	public String getData_consegna_prevista() {
		return data_consegna_prevista;
	}
	public void setData_consegna_prevista(String data_consegna_prevista) {
		this.data_consegna_prevista = data_consegna_prevista;
	}
	public String getData_consegna_effettuata() {
		return data_consegna_effettuata;
	}
	public void setData_consegna_effettuata(String data_consegna_effettuata) {
		this.data_consegna_effettuata = data_consegna_effettuata;
	}
	public String getCitt�() {
		return citt�;
	}
	public void setCitt�(String citt�) {
		this.citt� = citt�;
	}
	public String getVia() {
		return via;
	}
	public void setVia(String via) {
		this.via = via;
	}
	public String getCap() {
		return cap;
	}
	public void setCap(String cap) {
		this.cap = cap;
	}
	public String getFattura() {
		return fattura;
	}
	public void setFattura(String fattura) {
		
		this.fattura = fattura;
	}
	
	
}
