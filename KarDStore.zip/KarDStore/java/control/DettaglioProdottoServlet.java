package control;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.Prodotto;
import model.ProdottoDao;

@WebServlet("/DettaglioProdottoServlet")
public class DettaglioProdottoServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Recupera l'ID del prodotto dalla URL
        String productId = request.getParameter("id");
        int productIdint= Integer.parseInt(productId);
        // Recupera i dettagli del prodotto dal database usando l'ID
        Prodotto prodotto = ProdottoDao.getProdottoById(productIdint);
       
        // Passa il prodotto come attributo alla pagina JSP di dettaglio
        request.setAttribute("prodotto", prodotto);
        
       
        
        request.getRequestDispatcher("/dettaglioProdotto.jsp").forward(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }
}
