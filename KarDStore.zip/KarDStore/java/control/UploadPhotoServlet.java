package control;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import model.Prodotto;
import model.ProdottoDao;

@WebServlet("/UploadPhotoServlet")
@MultipartConfig(fileSizeThreshold=1024*1024*2, // 2MB
                 maxFileSize=1024*1024*10,      // 10MB
                 maxRequestSize=1024*1024*50)   // 50MB
public class UploadPhotoServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    static String SAVE_DIR = "/uploadTemp";

    public UploadPhotoServlet() {
        super();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        PrintWriter out = response.getWriter();
        response.setContentType("text/plain");
        out.write("Error: GET method is used but POST method is required");
        out.close();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String nome = request.getParameter("nome");
        String descrizione = request.getParameter("descrizione");
        String prezzo = request.getParameter("prezzo");
        String iva = request.getParameter("iva");
        String categoria = request.getParameter("select-categoria");
        String tipo = request.getParameter("select-tipo");
        String quantita_disponibile = request.getParameter("quantita");
     // Log per vedere i valori ricevuti
        System.out.println("Nome: " + nome);
        System.out.println("Descrizione: " + descrizione);
        System.out.println("Prezzo: " + prezzo);
        System.out.println("IVA: " + iva);
        System.out.println("Categoria: " + categoria);
        System.out.println("Tipo: " + tipo);
        System.out.println("Quantit�: " + quantita_disponibile);

        if (nome == null || descrizione == null || prezzo == null || iva == null || categoria == null || tipo == null || quantita_disponibile == null) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Missing parameters");
            return;
        }
        int quantita_disponibileInt = Integer.parseInt(quantita_disponibile);
        float prezzoFloat = Float.parseFloat(prezzo);
        float ivaFloat = Float.parseFloat(iva);
        Prodotto p = new Prodotto(nome, descrizione, prezzoFloat, ivaFloat, tipo, categoria, quantita_disponibileInt);

        String appPath = request.getServletContext().getRealPath("");
        String savePath = appPath + File.separator + SAVE_DIR;

        File fileSaveDir = new File(savePath);
        if (!fileSaveDir.exists()) {
            fileSaveDir.mkdir();
        }

        for (Part part : request.getParts()) {
            String fileName = extractFileName(part);
            if (fileName != null && !fileName.isEmpty()) {
                String filePath = savePath + File.separator + fileName;
                part.write(filePath);
                try {
                    ProdottoDao.addProdotto(p, filePath);
                } catch (Exception e) {
                    e.printStackTrace();
                    request.getSession().setAttribute("addprd", "Errore nell'inserimento del prodotto!");
                    response.sendRedirect("nuovo_prodotto.jsp");
                    return;
                }
            }
        }

        RequestDispatcher view = request.getRequestDispatcher("/nuovo_prodotto.jsp");
        request.getSession().setAttribute("addprd", "Prodotto inserito con successo!");
        view.forward(request, response);
    }

    private String extractFileName(Part part) {
        String contentDisp = part.getHeader("content-disposition");
        String[] items = contentDisp.split(";");
        for (String s : items) {
            if (s.trim().startsWith("filename")) {
                return s.substring(s.indexOf("=") + 2, s.length() - 1);
            }
        }
        return "";
    }
}
