package control;

import java.io.IOException;
import java.io.OutputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.ConDB;
import model.OrderDao;
import model.Ordine;

@WebServlet("/DownloadFatturaServlet")
public class DownloadFatturaServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public DownloadFatturaServlet() {
        super();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String ordineId = request.getParameter("ordineId");
        if (ordineId != null) {
            Ordine o = OrderDao.getOrdineById(Integer.parseInt(ordineId));
            if (o != null) {
                try (Connection conn = ConDB.Connessione()) {
                    String query = "SELECT immagine_fattura FROM ordine WHERE id = ?";
                    try (PreparedStatement ps = conn.prepareStatement(query)) {
                        ps.setInt(1, o.getId());
                        try (ResultSet rs = ps.executeQuery()) {
                            if (rs.next()) {
                                byte[] fileBytes = rs.getBytes("immagine_fattura");
                                if (fileBytes != null) {
                                    response.setContentType("application/jpeg");
                                    response.setHeader("Content-Disposition", "attachment; filename=fattura.jpeg");
                                    response.setContentLength(fileBytes.length);

                                    try (OutputStream os = response.getOutputStream()) {
                                        os.write(fileBytes);
                                        os.flush();
                                    }
                                } else {
                                    response.sendError(HttpServletResponse.SC_NOT_FOUND, "Fattura not found");
                                }
                            }
                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Error retrieving fattura");
                }
            } else {
                response.sendError(HttpServletResponse.SC_NOT_FOUND, "Order not found");
            }
        } else {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid order ID");
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }
}
