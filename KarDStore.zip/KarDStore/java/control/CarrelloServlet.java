package control;


import java.io.IOException;
import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Enumeration;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



import model.CarrelloDao;
import model.ProdottoDao;
import model.Carrello;
import model.ConDB;

@WebServlet("/cart")
public class CarrelloServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private CarrelloDao carrelloDao;

    public void init() throws ServletException {
    
         carrelloDao = new CarrelloDao();
        
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");
        String usernameUtente = request.getParameter("username_utente");

        try {
            switch (action) {
                case "add":
                    addItem(request, response, usernameUtente);
                    break;
                case "update":
                    updateItem(request, response, usernameUtente);
                    break;
                case "remove":
                    removeItem(request, response);
                    break;
                case "clear":
                    clearCart(request, response);
                    break;
                case "buy":
                	buyCart(request, response);
                	break;
                case "checkout":
                	toCheckout(request, response);
                	break;
                default:
                    listCart(request, response, usernameUtente);
                    break;
            }
        } catch (SQLException e) {
            throw new ServletException(e);
        }
    }

   /* private void addItem(HttpServletRequest request, HttpServletResponse response, String usernameUtente) throws SQLException, IOException {
        int codiceProdotto = Integer.parseInt(request.getParameter("codice_prodotto"));
        int quantita = Integer.parseInt(request.getParameter("quantit�"));
        Carrello item = new Carrello();
        item.setUsername_utente(usernameUtente);
        item.setCodice_prodotto(codiceProdotto);
        item.setQuantit�(quantita);
        carrelloDao.addItem(item);
        response.sendRedirect("cart?action=list&username_utente=" + usernameUtente);
    }*/
    
    
    private void buyCart(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException {
      /*  int id = Integer.parseInt(request.getParameter("codice_prodotto"));
        int quantita = Integer.parseInt(request.getParameter("quantita"));
        
        carrelloDao.updateItem(quantita,id,usernameUtente);
       
       */  clearCart(request,response);
       
    }
    
    private void toCheckout(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException, ServletException {
        /*  int id = Integer.parseInt(request.getParameter("codice_prodotto"));
          int quantita = Integer.parseInt(request.getParameter("quantita"));
          
          carrelloDao.updateItem(quantita,id,usernameUtente);
         
         */
    	String usr=request.getParameter("username_utente");
    	float tot=Float.parseFloat(request.getParameter("totale"));
    	request.getSession().setAttribute("username", usr);
    	request.getSession().setAttribute("totale", tot);
    	response.sendRedirect("checkout.jsp");
      }
    
    private void addItem(HttpServletRequest request, HttpServletResponse response, String usernameUtente) throws SQLException, IOException {
        String codiceProdottoParam = request.getParameter("codice_prodotto");
        String quantitaParam = request.getParameter("quantita");

        System.out.println("codice_prodotto: " + codiceProdottoParam);
        System.out.println("quantita: " + quantitaParam);
        System.out.println("username_utente: " + usernameUtente);

        if (codiceProdottoParam == null || quantitaParam == null) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "codice_prodotto or quantit� parameter is missing.");
 
            return;
        }
        int codiceProdotto = Integer.parseInt(codiceProdottoParam);
        int quantita = Integer.parseInt(quantitaParam);
        List<Carrello> carrello= carrelloDao.getCarrello(usernameUtente);
        for(Carrello ogg: carrello) {
        	if(ogg.getCodice_prodotto()==codiceProdotto) {
        		String referer = request.getHeader("Referer");
        		if(ProdottoDao.getProdottoById(ogg.getCodice_prodotto()).getQuantita_disponibile()<ogg.getQuantit�()+1){
    				request.getSession().setAttribute("error", true);
    				request.getSession().setAttribute("iderror", codiceProdotto);
        			response.sendRedirect(referer);
                    return;
    				
    			}
        		if(ProdottoDao.getProdottoById(ogg.getCodice_prodotto()).getQuantita_disponibile()==0) {
        			
        			request.getSession().setAttribute("error", true);
        			request.getSession().setAttribute("iderror", codiceProdotto);
        			response.sendRedirect(referer);
                    return;
        			
        		}
        		carrelloDao.updateItem(ogg.getQuantit�()+1, codiceProdotto, usernameUtente);
        		request.getSession().setAttribute("idadd", codiceProdotto);
        		
        		
                // Reindirizza l'utente alla pagina precedente
                response.sendRedirect(referer);
                return;
        		
        	}
        }
       

        Carrello item = new Carrello();
        item.setCodice_prodotto(codiceProdotto);
        String referer = request.getHeader("Referer");
        if(ProdottoDao.getProdottoById(item.getCodice_prodotto()).getQuantita_disponibile()==0) {
			request.getSession().setAttribute("error", true);
			request.getSession().setAttribute("iderror", codiceProdotto);
			response.sendRedirect(referer);
            return;
		}
        item.setUsername_utente(usernameUtente);
        
        item.setQuantit�(quantita);
        carrelloDao.addItem(item);
        request.getSession().setAttribute("idadd", codiceProdotto);
        

        // Reindirizza l'utente alla pagina precedente
        
        response.sendRedirect(referer);
    }


    private void updateItem(HttpServletRequest request, HttpServletResponse response, String usernameUtente) throws SQLException, IOException {
        int id = Integer.parseInt(request.getParameter("codice_prodotto"));
        int quantita = Integer.parseInt(request.getParameter("quantita"));
       
        carrelloDao.updateItem(quantita,id,usernameUtente);
        response.sendRedirect("Carrello.jsp");
    }

    private void removeItem(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException {
        int id = Integer.parseInt(request.getParameter("codice_prodotto"));
        String usr=request.getParameter("username_utente");
        carrelloDao.removeItem(id,usr);
        response.sendRedirect("Carrello.jsp");
    }

    private void clearCart(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException {
    	String usernameUtente = request.getParameter("username_utente");
    	carrelloDao.clearCart(usernameUtente);
        response.sendRedirect("Carrello.jsp");
    }

    private void listCart(HttpServletRequest request, HttpServletResponse response, String usernameUtente) throws SQLException, ServletException, IOException {
        List<Carrello> carrello = carrelloDao.getCarrello(usernameUtente);
        request.setAttribute("carrello", carrello);
        request.getRequestDispatcher("Carrello.jsp").forward(request, response);
    }
    @Override
    public void destroy() {
        super.destroy();
        try {
            Enumeration<Driver> drivers = DriverManager.getDrivers();
            while (drivers.hasMoreElements()) {
                Driver driver = drivers.nextElement();
                DriverManager.deregisterDriver(driver);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

}
