package control;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import model.Prodotto;
import model.ProdottoDao;

@WebServlet("/SearchServlet")
public class SearchServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public SearchServlet() {
        super();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String query = request.getParameter("query");
        System.out.println("Query ricevuta: " + query); // Debug
        ArrayList<Prodotto> prodotti = ProdottoDao.searchProdotti(query);

        response.setContentType("application/json");
        PrintWriter out = response.getWriter();

        StringBuilder json = new StringBuilder();
        json.append("[");
        
        for (int i = 0; i < prodotti.size(); i++) {
            Prodotto prodotto = prodotti.get(i);
            json.append("{");
            json.append("\"id\":").append(prodotto.getId()).append(",");
            json.append("\"nome\":\"").append(escapeJson(prodotto.getNome())).append("\",");
            json.append("\"descrizione\":\"").append(escapeJson(prodotto.getDescrizione())).append("\",");
            json.append("\"prezzo\":").append(prodotto.getPrezzo()).append(",");
            json.append("\"iva\":").append(prodotto.getIva()).append(",");
            json.append("\"img\":\"").append(escapeJson(prodotto.getImg())).append("\",");
            json.append("\"tipo\":\"").append(escapeJson(prodotto.getTipo())).append("\",");
            json.append("\"categoria\":\"").append(escapeJson(prodotto.getCategoria())).append("\",");
            json.append("\"quantita_disponibile\":").append(prodotto.getQuantita_disponibile());
            json.append("}");
            if (i < prodotti.size() - 1) {
                json.append(",");
            }
        }

        json.append("]");
        System.out.println("JSON generato: " + json.toString()); // Debug
        out.print(json.toString());
        out.flush();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }

    private String escapeJson(String value) {
        if (value == null) {
            return "";
        }
        return value.replace("\"", "\\\"")
                    .replace("\n", "\\n")
                    .replace("\r", "\\r")
                    .replace("\t", "\\t");
    }
}
