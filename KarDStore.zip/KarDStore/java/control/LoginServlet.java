package control;
import java.io.IOException;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.ConDB;
import model.OrderDao;
//import model.OrderModel;
import model.User;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public LoginServlet() {
        super();
    }

    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request, response);
    }

    /**
     * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        String redirectedPage = "/login.jsp";
        Boolean control = false;
        try {
            Connection con = ConDB.Connessione();
            String sql = "SELECT * FROM utente";
            
            PreparedStatement s = con.prepareStatement(sql);
            ResultSet rs = s.executeQuery();
            
            while (rs.next()) {
                if (username.compareTo(rs.getString(1)) == 0) {
                    String pw = checkPsw(password);
                    if (pw.compareTo(rs.getString(5)) == 0) {
                        control = true;
                        User registeredUser = new User();
                        registeredUser.setNome(rs.getString(2));
                        registeredUser.setCognome(rs.getString(3));
                        registeredUser.setEmail(rs.getString(4));
                        registeredUser.setTel(rs.getString(6));
                        registeredUser.setData_nascita(rs.getString(7));
                        registeredUser.setCitt�(rs.getString(8));
                        registeredUser.setVia(rs.getString(9));
                        registeredUser.setCap(rs.getString(10));
                        registeredUser.setTipo(rs.getString(11));
                        request.getSession().setAttribute("registeredUser", registeredUser);
                        request.getSession().setAttribute("role", registeredUser.getTipo());
                        request.getSession().setAttribute("username", rs.getString(1));
                        request.getSession().setAttribute("nome", rs.getString(6));
                        
                        
                        request.getSession().setAttribute("listaOrdini", OrderDao.getOrdiniByUsername(rs.getString(1)));
                        
                        redirectedPage = "/index.jsp";
                        ConDB.releaseConnection(con);
                    }
                }
            }
        }
        catch (Exception e) {
            redirectedPage = "/login.jsp";
        }
        if (!control) {
            request.getSession().setAttribute("login-error", true);
        } else {
            request.getSession().setAttribute("login-error", false);
        }
        response.sendRedirect(request.getContextPath() + redirectedPage);
    }
        
    private String checkPsw(String psw) {
        MessageDigest md = null;
        try {
            md = MessageDigest.getInstance("SHA-256");
        } catch (Exception e) {
            e.printStackTrace();
        }
        byte[] messageDigest = md.digest(psw.getBytes());
        BigInteger number = new BigInteger(1, messageDigest);
        String hashtext = number.toString(16);
        
        // Padding leading zeros to make it 32 characters long (256 bits)
        while (hashtext.length() < 64) {
            hashtext = "0" + hashtext;
        }
        
        return hashtext;
    }
}
