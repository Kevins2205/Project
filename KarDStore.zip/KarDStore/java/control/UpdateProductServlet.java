package control;


import model.Prodotto;
import model.ProdottoDao;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/updateProduct")
public class UpdateProductServlet extends HttpServlet {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int id = Integer.parseInt(request.getParameter("id_prodotto"));
        String nome = request.getParameter("nome");
        String descrizione = request.getParameter("descrizione");
        float prezzo = Float.parseFloat(request.getParameter("prezzo"));
        float iva = Float.parseFloat(request.getParameter("iva"));
        int quantita = Integer.parseInt(request.getParameter("quantita"));

        Prodotto prodotto = new Prodotto(nome, descrizione, prezzo, iva, quantita);
        prodotto.setId(id);
        ProdottoDao.updateProdotto(prodotto);

        response.sendRedirect("index.jsp"); // Redirige al catalogo dei prodotti
    }
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	doPost(request,response);
    }
}
