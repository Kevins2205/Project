package control;

import java.io.IOException;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.ConDB;

@WebServlet("/RegisterServlet")
public class RegisterServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public RegisterServlet() {
        super();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");
        if ("checkEmail".equals(action)) {
            checkEmail(request, response);
        } else if("checkUsername".equals(action)){
        	checkUsername(request, response);
        }
        else {
            registerUser(request, response);
        }
    }

    private void checkEmail(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String email = request.getParameter("email");
        boolean emailExists = false;

        try {
            Connection con = ConDB.Connessione();
            String sql = "SELECT 1 FROM utente WHERE email = ?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, email);
            ResultSet rs = ps.executeQuery();
            emailExists = rs.next();
            ConDB.releaseConnection(con);
        } catch (SQLException e) {
            e.printStackTrace();
        }

        response.setContentType("application/json");
        response.getWriter().write("{\"emailExists\": " + emailExists + "}");
    }
    
    
    private void checkUsername(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String email = request.getParameter("username");
        boolean emailExists = false;

        try {
            Connection con = ConDB.Connessione();
            String sql = "SELECT 1 FROM utente WHERE username = ?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, email);
            ResultSet rs = ps.executeQuery();
            emailExists = rs.next();
            ConDB.releaseConnection(con);
        } catch (SQLException e) {
            e.printStackTrace();
        }

        response.setContentType("application/json");
        response.getWriter().write("{\"usernameExists\": " + emailExists + "}");
    }

    private void registerUser(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String username = request.getParameter("username");
        String nome = request.getParameter("nome");
        String cognome = request.getParameter("cognome");
        String email = request.getParameter("email");
        String pw = request.getParameter("pw");
        String tel = request.getParameter("tel");
        String data_nascita = request.getParameter("data_nascita");
        String citta = request.getParameter("citta");
        String via = request.getParameter("via");
        String cap = request.getParameter("cap");
        String redirectedPage = "/register.jsp";
        boolean registrationSuccess = false; 

       
        try {    
            
           
            String sql2 = "INSERT INTO utente(username, nome, cognome, email, pw, tel, data_nascita, citta , via, cap, tipo) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
           

          
                Connection con2 = ConDB.Connessione();    
                PreparedStatement ps2 = con2.prepareStatement(sql2);
                ps2.setString(1, username);
                ps2.setString(2, nome);
                ps2.setString(3, cognome);
                ps2.setString(4, email);
                ps2.setString(5, hash(pw));
                ps2.setString(6, tel);
                ps2.setString(7, data_nascita);
                ps2.setString(8, citta);
                ps2.setString(9, via);
                ps2.setString(10, cap);
                ps2.setString(11, "cliente");
                ps2.executeUpdate();
                con2.commit();
                ConDB.releaseConnection(con2);
                registrationSuccess=true;

        } catch (SQLException e) {
            e.printStackTrace();
            request.getSession().setAttribute("register-error", true);
            redirectedPage = "/register.jsp";
        }
        if (registrationSuccess) {
            request.getSession().setAttribute("message", "Registrazione effettuata con successo!");
        } else {
            request.getSession().setAttribute("message", "Registrazione fallita. Riprova.");
        }
        
        response.sendRedirect(request.getContextPath() + redirectedPage);
    }

    private String hash(String password) {
        MessageDigest md = null;
        try {
            md = MessageDigest.getInstance("SHA-256");
        } catch (Exception e) {
            e.printStackTrace();
        }
        byte[] messageDigest = md.digest(password.getBytes());
        BigInteger number = new BigInteger(1, messageDigest);
        String hashtext = number.toString(16);

        while (hashtext.length() < 64) {
            hashtext = "0" + hashtext;
        }
        return hashtext;
    }
}