package control;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.*;

/**
 * Servlet implementation class ConsegnaServlet
 */
@WebServlet("/ConsegnaServlet")
public class ConsegnaServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ConsegnaServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String username=request.getParameter("username_utente");
		float totale=Float.parseFloat(request.getParameter("totale"));
		String nome=request.getParameter("nome");
		String cognome=request.getParameter("cognome");
		String citt�=request.getParameter("citta");
		String via=request.getParameter("via");
		String cap=request.getParameter("cap");
		String credenziali=request.getParameter("credenziali");
		String numerocarta=request.getParameter("numerocarta");
		String scadenzacarta=request.getParameter("scadenzacarta");
		String selectedCard=request.getParameter("savedCard");
		String cvv=request.getParameter("cvv");
		String imgBase64=null;
		if(numerocarta!=null) {
			if(PagamentoDao.contains(numerocarta)) {
			request.getSession().setAttribute("checkout-msg", "la carta gia esiste...controlla in quelle salvate!");
			response.sendRedirect("checkout.jsp");
			return;
		}}
		Pagamento p= new Pagamento();
		if(credenziali!=null && numerocarta!=null && cvv!=null && scadenzacarta!=null) {
		
			
			p.setCredenziali_carta(credenziali);
			p.setCvv(Integer.parseInt(cvv));
			p.setData_scadenza(scadenzacarta);
			p.setNumero_carta(numerocarta);
			p.setUsername_utente(username);
			PagamentoDao.addMetodoPagamento(p);
		}
		Ordine o= new Ordine();
		o.setCap(cap);
		o.setCitt�(citt�);
		o.setCognome_consegna(cognome);
		o.setNome_consegna(nome);
		o.setPrezzo_totale(totale);
		o.setUsername_utente(username);
		o.setVia(via);
		int last=OrderDao.getLastOrdine();
		
		o.setId(last+1);
		System.out.println("ultimo ordine id: "+last);
		
		try {
			ArrayList<Acquisto> acquisti= new ArrayList<Acquisto>();
			OrderDao.addOrdine(o);
			CarrelloDao c= new CarrelloDao();
			List<Carrello> carrello= c.getCarrello(username);
			for(Carrello cart: carrello) {
				Acquisto a= new Acquisto();
				a.setCodice_ordine(o.getId());
				a.setCodice_prodotto(cart.getCodice_prodotto());
				a.setFoto_prodotto(ProdottoDao.getProdottoById(cart.getCodice_prodotto()).getImg());
				a.setIva_all_acquisto(ProdottoDao.getProdottoById(cart.getCodice_prodotto()).getIva());
				a.setNome_prodotto(ProdottoDao.getProdottoById(cart.getCodice_prodotto()).getNome());
				a.setPrezzo_all_acquisto(ProdottoDao.getProdottoById(cart.getCodice_prodotto()).getPrezzo());
				a.setQuantit�(cart.getQuantit�());
				AcquistoDao.addAcquisto(a);
				acquisti.add(a);
				ProdottoDao.updateQuantit�(cart.getQuantit�(), ProdottoDao.getProdottoById(cart.getCodice_prodotto()));
			}
			
			
			if(selectedCard!=null && credenziali==null) {
				String[] parts = selectedCard.split("-", 2);
				
				p.setCredenziali_carta(parts[0]);
				p.setNumero_carta(parts[1]);
				
			}
			
			imgBase64=FatturaDao.CreaFattura(acquisti, o, p);
			
			CarrelloDao carrelloDao = new CarrelloDao();
			carrelloDao.clearCart(username);
			
			OrderDao.setFatturaById(o,imgBase64);
			
			
		} 
		catch (SQLException e) {
			request.getSession().setAttribute("checkout-msg", "Qualcosa � andato storto...riprova!");
			response.sendRedirect("checkout.jsp");
			e.printStackTrace();
			return;
		}
		request.getSession().setAttribute("checkout-msg", "Grazie dell'acquisto, puoi controllare l'ordine nell'area utente!");
		
		response.sendRedirect(request.getContextPath() + "/Carrello.jsp");
		
	}

}
