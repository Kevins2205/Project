package control;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.Acquisto;
import model.AcquistoDao;


@WebServlet("/OrderDetailsServlet")
public class OrderDetailsServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public OrderDetailsServlet() {
        super();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Recupera il parametro dell'ID ordine dalla richiesta
        String ordineIdParam = request.getParameter("ordineId");
        
        // Verifica che il parametro esista e sia valido
        if (ordineIdParam != null && !ordineIdParam.trim().isEmpty()) {
            try {
                int ordineId = Integer.parseInt(ordineIdParam);
                ArrayList<Acquisto> acquisti = AcquistoDao.getAcquistiByOrdine(ordineId);
                request.setAttribute("acquisti", acquisti);
                request.getRequestDispatcher("/orderDetails.jsp").forward(request, response);
            } catch (NumberFormatException e) {
            	System.out.println(ordineIdParam);
                response.sendRedirect("error.jsp"); // Gestione dell'errore
            }
        } else {
        	System.out.println(ordineIdParam);
            response.sendRedirect("error.jsp"); // Gestione dell'errore
        }
    }
}
